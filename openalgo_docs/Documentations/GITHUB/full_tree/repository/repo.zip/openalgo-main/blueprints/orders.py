import csv
import io
import os
from importlib import import_module

from flask import Blueprint, Response, jsonify, redirect, render_template, request, session, url_for

from database.auth_db import get_api_key_for_tradingview, get_auth_token
from database.settings_db import get_analyze_mode
from limiter import limiter
from services.close_position_service import close_position
from services.holdings_service import get_holdings
from services.orderbook_service import get_orderbook
from services.place_smart_order_service import place_smart_order
from services.positionbook_service import get_positionbook
from services.tradebook_service import get_tradebook
from utils.logging import get_logger
from utils.session import check_session_validity

logger = get_logger(__name__)

# Use existing rate limits from .env
API_RATE_LIMIT = os.getenv("API_RATE_LIMIT", "50 per second")

# Define the blueprint
orders_bp = Blueprint("orders_bp", __name__, url_prefix="/")


@orders_bp.errorhandler(429)
def ratelimit_handler(e):
    """Handle rate limit exceeded errors"""
    return jsonify(
        {"status": "error", "message": "Rate limit exceeded. Please try again later."}
    ), 429


def dynamic_import(broker, module_name, function_names):
    module_functions = {}
    try:
        # Import the module based on the broker name
        module = import_module(f"broker.{broker}.{module_name}")
        for name in function_names:
            module_functions[name] = getattr(module, name)
        return module_functions
    except (ImportError, AttributeError) as e:
        logger.error(
            f"Error importing functions {function_names} from {module_name} for broker {broker}: {e}"
        )

        return None


def generate_orderbook_csv(order_data):
    """Generate CSV file from orderbook data"""
    output = io.StringIO()
    writer = csv.writer(output)

    # Write headers matching the terminal display
    headers = [
        "Trading Symbol",
        "Exchange",
        "Transaction Type",
        "Quantity",
        "Price",
        "Trigger Price",
        "Order Type",
        "Product Type",
        "Order ID",
        "Status",
        "Time",
    ]
    writer.writerow(headers)

    # Write data in the same order as the headers
    for order in order_data:
        row = [
            order.get("symbol", ""),
            order.get("exchange", ""),
            order.get("action", ""),
            order.get("quantity", ""),
            order.get("price", ""),
            order.get("trigger_price", ""),
            order.get("pricetype", ""),
            order.get("product", ""),
            order.get("orderid", ""),
            order.get("order_status", ""),
            order.get("timestamp", ""),
        ]
        writer.writerow(row)

    return output.getvalue()


def generate_tradebook_csv(trade_data):
    """Generate CSV file from tradebook data"""
    output = io.StringIO()
    writer = csv.writer(output)

    # Write headers
    headers = [
        "Trading Symbol",
        "Exchange",
        "Product Type",
        "Transaction Type",
        "Fill Size",
        "Fill Price",
        "Trade Value",
        "Order ID",
        "Fill Time",
    ]
    writer.writerow(headers)

    # Write data
    for trade in trade_data:
        row = [
            trade.get("symbol", ""),
            trade.get("exchange", ""),
            trade.get("product", ""),
            trade.get("action", ""),
            trade.get("quantity", ""),
            trade.get("average_price", ""),
            trade.get("trade_value", ""),
            trade.get("orderid", ""),
            trade.get("timestamp", ""),
        ]
        writer.writerow(row)

    return output.getvalue()


def generate_positions_csv(positions_data):
    """Generate CSV file from positions data"""
    output = io.StringIO()
    writer = csv.writer(output)

    # Write headers - updated to match terminal output exactly
    headers = ["Symbol", "Exchange", "Product Type", "Net Qty", "Avg Price", "LTP", "P&L"]
    writer.writerow(headers)

    # Write data
    for position in positions_data:
        row = [
            position.get("symbol", ""),
            position.get("exchange", ""),
            position.get("product", ""),
            position.get("quantity", ""),
            position.get("average_price", ""),
            position.get("ltp", ""),
            position.get("pnl", ""),
        ]
        writer.writerow(row)

    return output.getvalue()


@orders_bp.route("/orderbook")
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def orderbook():
    login_username = session["user"]
    auth_token = get_auth_token(login_username)

    if auth_token is None:
        logger.warning(f"No auth token found for user {login_username}")
        return redirect(url_for("auth.logout"))

    broker = session.get("broker")
    if not broker:
        logger.error("Broker not set in session")
        return "Broker not set in session", 400

    # Check if in analyze mode and route accordingly
    if get_analyze_mode():
        # Get API key for sandbox mode
        api_key = get_api_key_for_tradingview(login_username)
        if api_key:
            success, response, status_code = get_orderbook(api_key=api_key)
        else:
            logger.error("No API key found for analyze mode")
            return "API key required for analyze mode", 400
    else:
        # Use live broker
        success, response, status_code = get_orderbook(auth_token=auth_token, broker=broker)

    if not success:
        logger.error(f"Failed to get orderbook data: {response.get('message', 'Unknown error')}")
        if status_code == 404:
            return "Failed to import broker module", 500
        return redirect(url_for("auth.logout"))

    data = response.get("data", {})
    order_data = data.get("orders", [])
    order_stats = data.get("statistics", {})

    return render_template("orderbook.html", order_data=order_data, order_stats=order_stats)


@orders_bp.route("/tradebook")
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def tradebook():
    login_username = session["user"]
    auth_token = get_auth_token(login_username)

    if auth_token is None:
        logger.warning(f"No auth token found for user {login_username}")
        return redirect(url_for("auth.logout"))

    broker = session.get("broker")
    if not broker:
        logger.error("Broker not set in session")
        return "Broker not set in session", 400

    # Check if in analyze mode and route accordingly
    if get_analyze_mode():
        # Get API key for sandbox mode
        api_key = get_api_key_for_tradingview(login_username)
        if api_key:
            success, response, status_code = get_tradebook(api_key=api_key)
        else:
            logger.error("No API key found for analyze mode")
            return "API key required for analyze mode", 400
    else:
        # Use live broker
        success, response, status_code = get_tradebook(auth_token=auth_token, broker=broker)

    if not success:
        logger.error(f"Failed to get tradebook data: {response.get('message', 'Unknown error')}")
        if status_code == 404:
            return "Failed to import broker module", 500
        return redirect(url_for("auth.logout"))

    tradebook_data = response.get("data", [])

    return render_template("tradebook.html", tradebook_data=tradebook_data)


@orders_bp.route("/positions")
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def positions():
    login_username = session["user"]
    auth_token = get_auth_token(login_username)

    if auth_token is None:
        logger.warning(f"No auth token found for user {login_username}")
        return redirect(url_for("auth.logout"))

    broker = session.get("broker")
    if not broker:
        logger.error("Broker not set in session")
        return "Broker not set in session", 400

    # Check if in analyze mode and route accordingly
    if get_analyze_mode():
        # Get API key for sandbox mode
        api_key = get_api_key_for_tradingview(login_username)
        if api_key:
            success, response, status_code = get_positionbook(api_key=api_key)
        else:
            logger.error("No API key found for analyze mode")
            return "API key required for analyze mode", 400
    else:
        # Use live broker
        success, response, status_code = get_positionbook(auth_token=auth_token, broker=broker)

    if not success:
        logger.error(f"Failed to get positions data: {response.get('message', 'Unknown error')}")
        if status_code == 404:
            return "Failed to import broker module", 500
        return redirect(url_for("auth.logout"))

    positions_data = response.get("data", [])

    return render_template("positions.html", positions_data=positions_data)


@orders_bp.route("/holdings")
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def holdings():
    login_username = session["user"]
    auth_token = get_auth_token(login_username)

    if auth_token is None:
        logger.warning(f"No auth token found for user {login_username}")
        return redirect(url_for("auth.logout"))

    broker = session.get("broker")
    if not broker:
        logger.error("Broker not set in session")
        return "Broker not set in session", 400

    # Check if in analyze mode and route accordingly
    if get_analyze_mode():
        # Get API key for sandbox mode
        api_key = get_api_key_for_tradingview(login_username)
        if api_key:
            success, response, status_code = get_holdings(api_key=api_key)
        else:
            logger.error("No API key found for analyze mode")
            return "API key required for analyze mode", 400
    else:
        # Use live broker
        success, response, status_code = get_holdings(auth_token=auth_token, broker=broker)

    if not success:
        logger.error(f"Failed to get holdings data: {response.get('message', 'Unknown error')}")
        if status_code == 404:
            return "Failed to import broker module", 500
        return redirect(url_for("auth.logout"))

    data = response.get("data", {})
    holdings_data = data.get("holdings", [])
    portfolio_stats = data.get("statistics", {})

    return render_template(
        "holdings.html", holdings_data=holdings_data, portfolio_stats=portfolio_stats
    )


@orders_bp.route("/orderbook/export")
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def export_orderbook():
    try:
        login_username = session["user"]
        auth_token = get_auth_token(login_username)
        broker = session.get("broker")

        if auth_token is None:
            logger.warning(f"No auth token found for user {login_username}")
            return redirect(url_for("auth.logout"))

        # Check if in analyze mode and route accordingly
        if get_analyze_mode():
            # Get API key for sandbox mode
            api_key = get_api_key_for_tradingview(login_username)
            if api_key:
                success, response, status_code = get_orderbook(api_key=api_key)
                if not success:
                    logger.error("Failed to get orderbook data in analyze mode")
                    return "Error getting orderbook data", 500
                data = response.get("data", {})
                order_data = data.get("orders", [])
            else:
                logger.error("No API key found for analyze mode")
                return "API key required for analyze mode", 400
        else:
            # Use live broker
            if not broker:
                logger.error("Broker not set in session")
                return "Broker not set in session", 400

            api_funcs = dynamic_import(broker, "api.order_api", ["get_order_book"])
            mapping_funcs = dynamic_import(
                broker, "mapping.order_data", ["map_order_data", "transform_order_data"]
            )

            if not api_funcs or not mapping_funcs:
                logger.error(f"Error loading broker-specific modules for {broker}")
                return "Error loading broker-specific modules", 500

            order_data = api_funcs["get_order_book"](auth_token)
            if "status" in order_data and order_data["status"] == "error":
                logger.error("Error in order data response")
                return redirect(url_for("auth.logout"))

            order_data = mapping_funcs["map_order_data"](order_data=order_data)
            order_data = mapping_funcs["transform_order_data"](order_data)

        csv_data = generate_orderbook_csv(order_data)
        return Response(
            csv_data,
            mimetype="text/csv",
            headers={"Content-Disposition": "attachment; filename=orderbook.csv"},
        )
    except Exception as e:
        logger.exception(f"Error exporting orderbook: {str(e)}")
        return "Error exporting orderbook", 500


@orders_bp.route("/tradebook/export")
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def export_tradebook():
    try:
        login_username = session["user"]
        auth_token = get_auth_token(login_username)
        broker = session.get("broker")

        if auth_token is None:
            logger.warning(f"No auth token found for user {login_username}")
            return redirect(url_for("auth.logout"))

        # Check if in analyze mode and route accordingly
        if get_analyze_mode():
            # Get API key for sandbox mode
            api_key = get_api_key_for_tradingview(login_username)
            if api_key:
                success, response, status_code = get_tradebook(api_key=api_key)
                if not success:
                    logger.error("Failed to get tradebook data in analyze mode")
                    return "Error getting tradebook data", 500
                tradebook_data = response.get("data", [])
            else:
                logger.error("No API key found for analyze mode")
                return "API key required for analyze mode", 400
        else:
            # Use live broker
            if not broker:
                logger.error("Broker not set in session")
                return "Broker not set in session", 400

            api_funcs = dynamic_import(broker, "api.order_api", ["get_trade_book"])
            mapping_funcs = dynamic_import(
                broker, "mapping.order_data", ["map_trade_data", "transform_tradebook_data"]
            )

            if not api_funcs or not mapping_funcs:
                logger.error(f"Error loading broker-specific modules for {broker}")
                return "Error loading broker-specific modules", 500

            tradebook_data = api_funcs["get_trade_book"](auth_token)
            if "status" in tradebook_data and tradebook_data["status"] == "error":
                logger.error("Error in tradebook data response")
                return redirect(url_for("auth.logout"))

            tradebook_data = mapping_funcs["map_trade_data"](tradebook_data)
            tradebook_data = mapping_funcs["transform_tradebook_data"](tradebook_data)

        csv_data = generate_tradebook_csv(tradebook_data)
        return Response(
            csv_data,
            mimetype="text/csv",
            headers={"Content-Disposition": "attachment; filename=tradebook.csv"},
        )
    except Exception as e:
        logger.exception(f"Error exporting tradebook: {str(e)}")
        return "Error exporting tradebook", 500


@orders_bp.route("/positions/export")
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def export_positions():
    try:
        login_username = session["user"]
        auth_token = get_auth_token(login_username)
        broker = session.get("broker")

        if auth_token is None:
            logger.warning(f"No auth token found for user {login_username}")
            return redirect(url_for("auth.logout"))

        # Check if in analyze mode and route accordingly
        if get_analyze_mode():
            # Get API key for sandbox mode
            api_key = get_api_key_for_tradingview(login_username)
            if api_key:
                success, response, status_code = get_positionbook(api_key=api_key)
                if not success:
                    logger.error("Failed to get positions data in analyze mode")
                    return "Error getting positions data", 500
                positions_data = response.get("data", [])
            else:
                logger.error("No API key found for analyze mode")
                return "API key required for analyze mode", 400
        else:
            # Use live broker
            if not broker:
                logger.error("Broker not set in session")
                return "Broker not set in session", 400

            api_funcs = dynamic_import(broker, "api.order_api", ["get_positions"])
            mapping_funcs = dynamic_import(
                broker, "mapping.order_data", ["map_position_data", "transform_positions_data"]
            )

            if not api_funcs or not mapping_funcs:
                logger.error(f"Error loading broker-specific modules for {broker}")
                return "Error loading broker-specific modules", 500

            positions_data = api_funcs["get_positions"](auth_token)
            if "status" in positions_data and positions_data["status"] == "error":
                logger.error("Error in positions data response")
                return redirect(url_for("auth.logout"))

            positions_data = mapping_funcs["map_position_data"](positions_data)
            positions_data = mapping_funcs["transform_positions_data"](positions_data)

        csv_data = generate_positions_csv(positions_data)
        return Response(
            csv_data,
            mimetype="text/csv",
            headers={"Content-Disposition": "attachment; filename=positions.csv"},
        )
    except Exception as e:
        logger.exception(f"Error exporting positions: {str(e)}")
        return "Error exporting positions", 500


@orders_bp.route("/close_position", methods=["POST"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def close_position():
    """Close a specific position - uses broker API in live mode, placesmartorder service in analyze mode"""
    try:
        # Get data from request
        data = request.json
        symbol = data.get("symbol")
        exchange = data.get("exchange")
        product = data.get("product")

        if not all([symbol, exchange, product]):
            return jsonify(
                {
                    "status": "error",
                    "message": "Missing required parameters (symbol, exchange, product)",
                }
            ), 400

        # Get auth token from session
        login_username = session["user"]
        auth_token = get_auth_token(login_username)
        broker_name = session.get("broker")

        # Check if in analyze mode
        if get_analyze_mode():
            # In analyze mode, use placesmartorder service with quantity=0 and position_size=0
            api_key = get_api_key_for_tradingview(login_username)

            if not api_key:
                return jsonify(
                    {"status": "error", "message": "API key not found for analyze mode"}
                ), 401

            # Prepare order data for placesmartorder service (without apikey in data)
            order_data = {
                "strategy": "UI Exit Position",
                "exchange": exchange,
                "symbol": symbol,
                "action": "BUY",  # Will be determined by smart order logic
                "product_type": product,
                "pricetype": "MARKET",
                "quantity": "0",
                "price": "0",
                "trigger_price": "0",
                "disclosed_quantity": "0",
                "position_size": "0",  # Setting to 0 to close the position
            }

            # Use placesmartorder service for analyze mode
            from services.place_smart_order_service import place_smart_order

            # Pass api_key as a separate parameter for analyze mode
            success, response_data, status_code = place_smart_order(
                order_data=order_data, api_key=api_key
            )
            return jsonify(response_data), status_code

        # Live mode - continue with existing logic
        if not auth_token or not broker_name:
            return jsonify({"status": "error", "message": "Authentication error"}), 401

        # Dynamically import broker-specific modules for API
        api_funcs = dynamic_import(
            broker_name, "api.order_api", ["place_smartorder_api", "get_open_position"]
        )

        if not api_funcs:
            logger.error(f"Error loading broker-specific modules for {broker_name}")
            return jsonify({"status": "error", "message": "Error loading broker modules"}), 500

        # Get the functions we need
        place_smartorder_api = api_funcs["place_smartorder_api"]

        # Prepare order data for direct broker API call
        order_data = {
            "strategy": "UI Exit Position",
            "exchange": exchange,
            "symbol": symbol,
            "action": "BUY",  # Will be determined by the smart order API based on current position
            "product": product,
            "pricetype": "MARKET",
            "quantity": "0",
            "price": "0",
            "trigger_price": "0",
            "disclosed_quantity": "0",
            "position_size": "0",  # Setting to 0 to close the position
        }

        # Call the broker API directly
        res, response, orderid = place_smartorder_api(order_data, auth_token)

        # Format the response based on presence of orderid and broker's response
        if orderid:
            response_data = {
                "status": "success",
                "message": response.get("message")
                if response and "message" in response
                else "Position close order placed successfully.",
                "orderid": orderid,
            }
            status_code = 200

            # Publish event for logging, socketio, and telegram (fixes missing API log)
            api_key = get_api_key_for_tradingview(login_username)
            if api_key:
                from events import PositionClosedEvent
                from utils.event_bus import bus

                log_request = order_data.copy()
                log_request["api_type"] = "closeposition"

                bus.publish(PositionClosedEvent(
                    mode="live",
                    api_type="closeposition",
                    symbol=symbol,
                    exchange=exchange,
                    product=product,
                    orderid=str(orderid),
                    message="Position close order placed successfully.",
                    request_data=log_request,
                    response_data=response_data,
                    api_key=api_key,
                ))
        else:
            # No orderid, definite error
            response_data = {
                "status": "error",
                "message": response.get("message")
                if response and "message" in response
                else "Failed to close position (broker did not return order ID).",
            }
            if res and hasattr(res, "status") and isinstance(res.status, int) and res.status >= 400:
                status_code = res.status  # Use broker's HTTP error code if available
            else:
                status_code = 400  # Default to Bad Request

        return jsonify(response_data), status_code

    except Exception as e:
        logger.exception(f"Error in close_position endpoint: {str(e)}")
        return jsonify({"status": "error", "message": f"An error occurred: {str(e)}"}), 500


@orders_bp.route("/close_all_positions", methods=["POST"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def close_all_positions():
    """Close all open positions using the broker API"""
    try:
        # Get auth token from session
        login_username = session["user"]
        auth_token = get_auth_token(login_username)
        broker_name = session.get("broker")

        if not auth_token or not broker_name:
            return jsonify({"status": "error", "message": "Authentication error"}), 401

        # Import necessary functions
        from database.auth_db import get_api_key_for_tradingview
        from database.settings_db import get_analyze_mode
        from services.close_position_service import close_position

        # Get API key for analyze mode
        api_key = None
        if get_analyze_mode():
            api_key = get_api_key_for_tradingview(login_username)

        # Call the service with appropriate parameters
        success, response_data, status_code = close_position(
            position_data={}, api_key=api_key, auth_token=auth_token, broker=broker_name
        )

        # Format the response for UI
        if success and status_code == 200:
            return jsonify(
                {
                    "status": "success",
                    "message": response_data.get("message", "All Open Positions Squared Off"),
                }
            ), 200
        else:
            return jsonify(response_data), status_code

    except Exception as e:
        logger.exception(f"Error in close_all_positions endpoint: {str(e)}")
        return jsonify({"status": "error", "message": f"An error occurred: {str(e)}"}), 500


@orders_bp.route("/cancel_all_orders", methods=["POST"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def cancel_all_orders_ui():
    """Cancel all open orders using the broker API from UI"""
    try:
        # Get auth token from session
        login_username = session["user"]
        auth_token = get_auth_token(login_username)
        broker_name = session.get("broker")

        if not auth_token or not broker_name:
            return jsonify({"status": "error", "message": "Authentication error"}), 401

        # Import necessary functions
        from database.auth_db import get_api_key_for_tradingview
        from database.settings_db import get_analyze_mode
        from services.cancel_all_order_service import cancel_all_orders

        # Get API key for analyze mode
        api_key = None
        if get_analyze_mode():
            api_key = get_api_key_for_tradingview(login_username)

        # Call the service with appropriate parameters
        success, response_data, status_code = cancel_all_orders(
            order_data={}, api_key=api_key, auth_token=auth_token, broker=broker_name
        )

        # Format the response for UI
        if success and status_code == 200:
            canceled_count = len(response_data.get("canceled_orders", []))
            failed_count = len(response_data.get("failed_cancellations", []))

            if canceled_count > 0 or failed_count == 0:
                message = f"Successfully canceled {canceled_count} orders"
                if failed_count > 0:
                    message += f" (Failed to cancel {failed_count} orders)"
                return jsonify(
                    {
                        "status": "success",
                        "message": message,
                        "canceled_orders": response_data.get("canceled_orders", []),
                        "failed_cancellations": response_data.get("failed_cancellations", []),
                    }
                ), 200
            else:
                return jsonify({"status": "info", "message": "No open orders to cancel"}), 200
        else:
            return jsonify(response_data), status_code

    except Exception as e:
        logger.exception(f"Error in cancel_all_orders_ui endpoint: {str(e)}")
        return jsonify({"status": "error", "message": f"An error occurred: {str(e)}"}), 500


@orders_bp.route("/cancel_order", methods=["POST"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def cancel_order_ui():
    """Cancel a single order using the broker API from UI"""
    try:
        # Get auth token from session
        login_username = session["user"]
        auth_token = get_auth_token(login_username)
        broker_name = session.get("broker")

        if not auth_token or not broker_name:
            return jsonify({"status": "error", "message": "Authentication error"}), 401

        # Get order ID from request
        data = request.get_json()
        orderid = data.get("orderid")

        if not orderid:
            return jsonify({"status": "error", "message": "Order ID is required"}), 400

        # Import necessary functions
        from database.auth_db import get_api_key_for_tradingview
        from database.settings_db import get_analyze_mode
        from services.cancel_order_service import cancel_order

        # Get API key for analyze mode
        api_key = None
        if get_analyze_mode():
            api_key = get_api_key_for_tradingview(login_username)

        # Call the service with appropriate parameters
        success, response_data, status_code = cancel_order(
            orderid=orderid, api_key=api_key, auth_token=auth_token, broker=broker_name
        )

        return jsonify(response_data), status_code

    except Exception as e:
        logger.exception(f"Error in cancel_order_ui endpoint: {str(e)}")
        return jsonify({"status": "error", "message": f"An error occurred: {str(e)}"}), 500


@orders_bp.route("/modify_gtt_order", methods=["POST"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def modify_gtt_order_ui():
    """Modify an active GTT trigger from the UI (session-auth).

    Accepts the flat replacement body — same shape as PlaceGTTOrder plus
    ``trigger_id``. ``last_price`` is fetched server-side by the broker.
    """
    try:
        login_username = session["user"]
        auth_token = get_auth_token(login_username)
        broker_name = session.get("broker")

        if not auth_token or not broker_name:
            return jsonify({"status": "error", "message": "Authentication error"}), 401

        data = request.get_json() or {}
        trigger_id = data.get("trigger_id")
        if not trigger_id:
            return jsonify({"status": "error", "message": "trigger_id is required"}), 400

        from services.modify_gtt_order_service import modify_gtt_order

        api_key = None
        if get_analyze_mode():
            api_key = get_api_key_for_tradingview(login_username)

        order_data = {
            "trigger_id": str(trigger_id),
            "strategy": data.get("strategy", "GTT Modify"),
            "symbol": data.get("symbol"),
            "exchange": data.get("exchange"),
            "trigger_type": data.get("trigger_type"),
            "action": data.get("action"),
            "product": data.get("product"),
            "quantity": data.get("quantity"),
            "pricetype": data.get("pricetype", "LIMIT"),
            "price": data.get("price"),
            "triggerprice_sl": data.get("triggerprice_sl"),
            "triggerprice_tg": data.get("triggerprice_tg"),
            "stoploss": data.get("stoploss"),
            "target": data.get("target"),
        }

        success, response_data, status_code = modify_gtt_order(
            order_data=order_data,
            api_key=api_key,
            auth_token=auth_token,
            broker=broker_name,
        )
        return jsonify(response_data), status_code

    except Exception as e:
        logger.exception(f"Error in modify_gtt_order_ui endpoint: {str(e)}")
        return jsonify({"status": "error", "message": f"An error occurred: {str(e)}"}), 500


@orders_bp.route("/cancel_gtt_order", methods=["POST"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def cancel_gtt_order_ui():
    """Cancel a GTT trigger using the broker API from UI (session-auth)."""
    try:
        login_username = session["user"]
        auth_token = get_auth_token(login_username)
        broker_name = session.get("broker")

        if not auth_token or not broker_name:
            return jsonify({"status": "error", "message": "Authentication error"}), 401

        data = request.get_json() or {}
        trigger_id = data.get("trigger_id")
        if not trigger_id:
            return jsonify({"status": "error", "message": "trigger_id is required"}), 400

        from services.cancel_gtt_order_service import cancel_gtt_order

        api_key = None
        if get_analyze_mode():
            api_key = get_api_key_for_tradingview(login_username)

        success, response_data, status_code = cancel_gtt_order(
            trigger_id=str(trigger_id),
            api_key=api_key,
            auth_token=auth_token,
            broker=broker_name,
        )
        return jsonify(response_data), status_code

    except Exception as e:
        logger.exception(f"Error in cancel_gtt_order_ui endpoint: {str(e)}")
        return jsonify({"status": "error", "message": f"An error occurred: {str(e)}"}), 500


@orders_bp.route("/modify_order", methods=["POST"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def modify_order_ui():
    """Modify an order using the broker API from UI"""
    try:
        # Get auth token from session
        login_username = session["user"]
        auth_token = get_auth_token(login_username)
        broker_name = session.get("broker")

        if not auth_token or not broker_name:
            return jsonify({"status": "error", "message": "Authentication error"}), 401

        # Get order data from request
        data = request.get_json()
        orderid = data.get("orderid")

        if not orderid:
            return jsonify({"status": "error", "message": "Order ID is required"}), 400

        # Import necessary functions
        from database.auth_db import get_api_key_for_tradingview
        from database.settings_db import get_analyze_mode
        from services.modify_order_service import modify_order

        # Get API key for analyze mode
        api_key = None
        if get_analyze_mode():
            api_key = get_api_key_for_tradingview(login_username)

        # Build order data for modification
        order_data = {
            "orderid": orderid,
            "symbol": data.get("symbol"),
            "exchange": data.get("exchange"),
            "action": data.get("action"),
            "product": data.get("product"),
            "pricetype": data.get("pricetype"),
            "price": data.get("price"),
            "quantity": data.get("quantity"),
            "disclosed_quantity": data.get("disclosed_quantity", 0),
            "trigger_price": data.get("trigger_price", 0),
        }

        # Call the service with appropriate parameters
        success, response_data, status_code = modify_order(
            order_data=order_data, api_key=api_key, auth_token=auth_token, broker=broker_name
        )

        return jsonify(response_data), status_code

    except Exception as e:
        logger.exception(f"Error in modify_order_ui endpoint: {str(e)}")
        return jsonify({"status": "error", "message": f"An error occurred: {str(e)}"}), 500


@orders_bp.route("/action-center")
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def action_center():
    """
    Action Center - Manage pending semi-automated orders
    Similar to orderbook but for pending approval orders
    """
    login_username = session["user"]

    # Get filter from query params
    status_filter = request.args.get("status", "pending")  # pending, approved, rejected, all

    # Get action center data
    from services.action_center_service import get_action_center_data

    if status_filter == "all":
        success, response, status_code = get_action_center_data(login_username, status_filter=None)
    else:
        success, response, status_code = get_action_center_data(
            login_username, status_filter=status_filter
        )

    if not success:
        logger.error(
            f"Failed to get action center data: {response.get('message', 'Unknown error')}"
        )
        return render_template(
            "action_center.html",
            order_data=[],
            order_stats={},
            current_filter=status_filter,
            login_username=login_username,
        )

    data = response.get("data", {})
    order_data = data.get("orders", [])
    order_stats = data.get("statistics", {})

    return render_template(
        "action_center.html",
        order_data=order_data,
        order_stats=order_stats,
        current_filter=status_filter,
        login_username=login_username,
    )


@orders_bp.route("/action-center/approve/<int:order_id>", methods=["POST"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def approve_pending_order_route(order_id):
    """Approve a pending order and execute it"""
    login_username = session["user"]

    from database.action_center_db import approve_pending_order
    from extensions import socketio
    from services.pending_order_execution_service import execute_approved_order

    # Approve the order
    success = approve_pending_order(order_id, login_username, login_username)

    if success:
        # Execute the order
        exec_success, response_data, status_code = execute_approved_order(order_id)

        # Emit socket event to notify about order approval
        socketio.emit(
            "pending_order_updated",
            {"action": "approved", "order_id": order_id, "user_id": login_username},
        )

        if exec_success:
            return jsonify(
                {
                    "status": "success",
                    "message": "Order approved and executed successfully",
                    "broker_order_id": response_data.get("orderid"),
                }
            )
        else:
            return jsonify(
                {
                    "status": "warning",
                    "message": "Order approved but execution failed",
                    "error": response_data.get("message"),
                }
            ), status_code
    else:
        return jsonify({"status": "error", "message": "Failed to approve order"}), 400


@orders_bp.route("/action-center/reject/<int:order_id>", methods=["POST"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def reject_pending_order_route(order_id):
    """Reject a pending order"""
    login_username = session["user"]
    data = request.json
    reason = data.get("reason", "No reason provided")

    from database.action_center_db import reject_pending_order
    from extensions import socketio

    success = reject_pending_order(order_id, reason, login_username, login_username)

    if success:
        # Emit socket event to notify about order rejection
        socketio.emit(
            "pending_order_updated",
            {"action": "rejected", "order_id": order_id, "user_id": login_username},
        )

        return jsonify({"status": "success", "message": "Order rejected successfully"})
    else:
        return jsonify({"status": "error", "message": "Failed to reject order"}), 400


@orders_bp.route("/action-center/delete/<int:order_id>", methods=["DELETE"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def delete_pending_order_route(order_id):
    """Delete a pending order (only if not pending)"""
    login_username = session["user"]

    from database.action_center_db import delete_pending_order
    from extensions import socketio

    success = delete_pending_order(order_id, login_username)

    if success:
        # Emit socket event to notify about order deletion
        socketio.emit(
            "pending_order_updated",
            {"action": "deleted", "order_id": order_id, "user_id": login_username},
        )

        return jsonify({"status": "success", "message": "Order deleted successfully"})
    else:
        return jsonify({"status": "error", "message": "Failed to delete order"}), 400


@orders_bp.route("/action-center/count")
@check_session_validity
def action_center_count():
    """Get count of pending orders for badge"""
    login_username = session["user"]

    from database.action_center_db import get_pending_count

    count = get_pending_count(login_username)

    return jsonify({"count": count})


@orders_bp.route("/action-center/approve-all", methods=["POST"])
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def approve_all_pending_orders():
    """Approve and execute all pending orders"""
    login_username = session["user"]

    from database.action_center_db import approve_pending_order, get_pending_orders
    from extensions import socketio
    from services.pending_order_execution_service import execute_approved_order

    # Get all pending orders for this user
    pending_orders = get_pending_orders(login_username, status="pending")

    if not pending_orders:
        return jsonify({"status": "info", "message": "No pending orders to approve"}), 200

    # Track results
    approved_count = 0
    executed_count = 0
    failed_executions = []

    # Approve and execute each order
    for order in pending_orders:
        # Approve the order
        success = approve_pending_order(order.id, login_username, login_username)

        if success:
            approved_count += 1

            # Execute the order
            exec_success, response_data, status_code = execute_approved_order(order.id)

            if exec_success:
                executed_count += 1
            else:
                failed_executions.append(
                    {"order_id": order.id, "error": response_data.get("message", "Unknown error")}
                )

    # Emit socket event to notify about batch approval
    socketio.emit(
        "pending_order_updated",
        {"action": "batch_approved", "user_id": login_username, "count": approved_count},
    )

    # Prepare response message
    if approved_count == executed_count:
        message = f"Successfully approved and executed all {approved_count} orders"
        status = "success"
    elif executed_count > 0:
        message = f"Approved {approved_count} orders. {executed_count} executed successfully, {len(failed_executions)} failed"
        status = "warning"
    else:
        message = f"Approved {approved_count} orders but all executions failed"
        status = "error"

    return jsonify(
        {
            "status": status,
            "message": message,
            "approved_count": approved_count,
            "executed_count": executed_count,
            "failed_executions": failed_executions,
        }
    ), 200


@orders_bp.route("/action-center/api/data")
@check_session_validity
@limiter.limit(API_RATE_LIMIT)
def action_center_api_data():
    """
    Action Center JSON API - Get pending/approved/rejected orders data
    For React SPA consumption
    """
    login_username = session["user"]

    # Get filter from query params
    status_filter = request.args.get("status", "pending")  # pending, approved, rejected, all

    # Get action center data
    from services.action_center_service import get_action_center_data

    if status_filter == "all" or not status_filter:
        success, response, status_code = get_action_center_data(login_username, status_filter=None)
    else:
        success, response, status_code = get_action_center_data(
            login_username, status_filter=status_filter
        )

    if not success:
        logger.error(
            f"Failed to get action center data: {response.get('message', 'Unknown error')}"
        )
        return jsonify(
            {
                "status": "error",
                "message": response.get("message", "Failed to get action center data"),
                "data": {
                    "orders": [],
                    "statistics": {
                        "total_pending": 0,
                        "total_approved": 0,
                        "total_rejected": 0,
                        "total_buy_orders": 0,
                        "total_sell_orders": 0,
                    },
                },
            }
        ), status_code

    return jsonify({"status": "success", "data": response.get("data", {})})
