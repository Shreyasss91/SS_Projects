import os
import re
import secrets

from flask import (
    Blueprint,
    current_app,
    flash,
    jsonify,
    make_response,
    redirect,
    request,
    session,
    url_for,
)
from flask_wtf.csrf import generate_csrf

from database.auth_db import auth_cache, feed_token_cache, upsert_auth
from database.settings_db import get_smtp_settings, set_smtp_settings
from database.user_db import (  # Import the function
    User,
    authenticate_user,
    db_session,
    find_user_by_email,
    find_user_by_exact_username,
    find_user_by_username,
)
from extensions import socketio
from limiter import limiter  # Import the limiter instance
from utils.email_debug import debug_smtp_connection
from utils.email_utils import send_password_reset_email, send_test_email
from utils.ip_helper import get_real_ip
from utils.logging import get_logger
from utils.session import check_session_validity

# Initialize logger
logger = get_logger(__name__)

# Access environment variables
LOGIN_RATE_LIMIT_MIN = os.getenv("LOGIN_RATE_LIMIT_MIN", "5 per minute")
LOGIN_RATE_LIMIT_HOUR = os.getenv("LOGIN_RATE_LIMIT_HOUR", "25 per hour")
RESET_RATE_LIMIT = os.getenv("RESET_RATE_LIMIT", "15 per hour")  # Password reset rate limit

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")


def _utcnow_iso() -> str:
    """ISO timestamp used for TOTP freshness markers in the session."""
    from datetime import datetime

    return datetime.utcnow().isoformat()


# How long the password→TOTP step is allowed to dawdle before the pending
# session marker is expired. Short window — we want a stolen browser session
# without the TOTP app to time out, not allow indefinite retry.
_PENDING_TOTP_MAX_AGE_SECS = 300  # 5 minutes


def _pending_totp_is_fresh() -> bool:
    """True if the password step happened within the last 5 minutes."""
    started = session.get("pending_totp_started_at")
    if not started:
        return False
    try:
        from datetime import datetime, timedelta

        ts = datetime.fromisoformat(started)
        return datetime.utcnow() - ts <= timedelta(seconds=_PENDING_TOTP_MAX_AGE_SECS)
    except (TypeError, ValueError):
        return False


def _clear_pending_totp() -> None:
    session.pop("pending_totp_user", None)
    session.pop("pending_totp_started_at", None)


@auth_bp.errorhandler(429)
def ratelimit_handler(e):
    return jsonify(status="error", message="Too many login attempts. Please wait a minute and try again."), 429


@auth_bp.route("/csrf-token", methods=["GET"])
def get_csrf_token():
    """Return a CSRF token for React SPA to use in form submissions."""
    token = generate_csrf()
    return jsonify({"csrf_token": token})


@auth_bp.route("/broker-config", methods=["GET"])
def get_broker_config():
    """Return broker configuration for React SPA.

    broker_name is always returned (needed to display the broker login button).
    broker_api_key and redirect_url are only returned when authenticated.
    """
    REDIRECT_URL = os.getenv("REDIRECT_URL")

    # Extract broker name from redirect URL
    match = re.search(r"/([^/]+)/callback$", REDIRECT_URL)
    broker_name = match.group(1) if match else None

    if not broker_name:
        return jsonify({"status": "error", "message": "Broker not configured"}), 500

    # Return full config only for authenticated users
    if "user" in session:
        BROKER_API_KEY = os.getenv("BROKER_API_KEY")
        return jsonify(
            {
                "status": "success",
                "broker_name": broker_name,
                "broker_api_key": BROKER_API_KEY,
                "redirect_url": REDIRECT_URL,
            }
        )

    # Unauthenticated: return broker name only so the login button is visible
    return jsonify(
        {
            "status": "success",
            "broker_name": broker_name,
            "broker_api_key": None,
            "redirect_url": REDIRECT_URL,
        }
    )


@auth_bp.route("/check-setup", methods=["GET"])
def check_setup_required():
    """Check if initial setup is required (no users exist)."""
    needs_setup = find_user_by_username() is None
    return jsonify({"status": "success", "needs_setup": needs_setup})


def _try_resume_broker_session(username):
    """
    Check if the user has an existing valid broker session in the DB.
    If so, validate it with a lightweight funds API call and resume
    the session without requiring broker OAuth re-authentication.

    Returns a JSON response if session was resumed, or None to proceed
    with normal broker OAuth flow.
    """
    from database.auth_db import Auth, decrypt_token, get_auth_token_dbquery

    try:
        auth_obj = get_auth_token_dbquery(username)
        if not auth_obj or auth_obj.is_revoked:
            return None

        # Decrypt the stored broker token
        auth_token = decrypt_token(auth_obj.auth)
        if not auth_token:
            return None

        broker = auth_obj.broker
        feed_token = decrypt_token(auth_obj.feed_token) if auth_obj.feed_token else None
        user_id = auth_obj.user_id

        # Validate token with a lightweight broker API call (funds)
        import importlib
        try:
            broker_module = importlib.import_module(f"broker.{broker}.api.funds")
            funds_data = broker_module.get_margin_data(auth_token)
            # get_margin_data returns {} on failure (doesn't raise) — treat empty as invalid
            if not funds_data:
                logger.info(f"Broker token expired or invalid for {username} (empty funds response)")
                return None
        except Exception as e:
            logger.info(f"Broker token validation failed for {username}: {e}")
            return None

        # Token is valid — resume the session via handle_auth_success
        logger.info(f"Resuming existing broker session for {username} (broker: {broker})")

        from utils.auth_utils import handle_auth_success
        # Call handle_auth_success for its side effects (session setup, DB upsert,
        # master contract loading) but ignore its response format — the login
        # endpoint must always return JSON for the React frontend's fetch() call.
        try:
            handle_auth_success(
                auth_token=auth_token,
                user_session_key=username,
                broker=broker,
                feed_token=feed_token,
                user_id=user_id,
            )
        except Exception as e:
            logger.error(f"handle_auth_success failed during resume: {e}", exc_info=True)
            # Clear partial session state and fall through to OAuth
            session.pop("logged_in", None)
            session.pop("broker", None)
            session.pop("session_id", None)
            return None

        logger.info(f"Session resume complete for {username}, redirecting to dashboard")
        return jsonify({
            "status": "success",
            "message": "Broker session resumed",
            "redirect": "/dashboard",
            "broker": broker,
        }), 200

    except Exception as e:
        logger.error(f"Error trying to resume broker session: {e}", exc_info=True)
        return None


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit(LOGIN_RATE_LIMIT_MIN)
@limiter.limit(LOGIN_RATE_LIMIT_HOUR)
def login():
    # Handle POST requests first (for React SPA / AJAX login)
    if request.method == "POST":
        logger.info(f"[LOGIN] POST from IP={get_real_ip()}, UA={request.headers.get('User-Agent', '')[:80]}")
        logger.info(f"[LOGIN] Session state: user={session.get('user')}, logged_in={session.get('logged_in')}, broker={session.get('broker')}")

        # Check if setup is required
        if find_user_by_username() is None:
            logger.info("[LOGIN] No users exist, redirecting to setup")
            return jsonify(
                {
                    "status": "error",
                    "message": "Please complete initial setup first.",
                    "redirect": "/setup",
                }
            ), 400

        # Check if already logged in (check logged_in first — it means
        # broker auth is complete; "user" alone means only password was done)
        if session.get("logged_in"):
            logger.info(f"[LOGIN] Already fully logged in, redirecting to /dashboard")
            return jsonify(
                {"status": "success", "message": "Already logged in", "redirect": "/dashboard"}
            ), 200

        if "user" in session:
            logger.info(f"[LOGIN] User in session but not logged_in, redirecting to /broker")
            return jsonify(
                {"status": "success", "message": "Already logged in", "redirect": "/broker"}
            ), 200

        username = request.form["username"]
        password = request.form["password"]

        ip = get_real_ip()
        ua = request.headers.get("User-Agent", "")

        if authenticate_user(username, password):
            logger.info(f"[LOGIN] Password auth success for: {username}")

            # If the user has 2FA enabled for login, defer setting session["user"]
            # until TOTP is verified. This is the gate that prevents an attacker
            # with only the password from progressing to broker login. We park
            # the username on a transient key that POST /auth/login/totp will
            # consume on success, and clear on failure or timeout.
            user = find_user_by_exact_username(username)
            if user is not None and user.is_totp_required_for("login"):
                session.pop("user", None)
                session["pending_totp_user"] = username
                session["pending_totp_started_at"] = _utcnow_iso()
                logger.info(f"[LOGIN] TOTP required for: {username}; awaiting second factor")
                return jsonify(
                    {"status": "totp_required", "message": "Enter the 6-digit code from your authenticator app."}
                ), 200

            session["user"] = username  # Set the username in the session

            # Try to resume existing broker session (skip OAuth if token still valid)
            resumed = _try_resume_broker_session(username)
            logger.info(f"[LOGIN] Resume result: {resumed is not None}, type={type(resumed).__name__ if resumed else 'None'}")
            if resumed:
                logger.info(f"[LOGIN] Returning resume response to frontend")
                from database.auth_db import log_login_attempt
                log_login_attempt(username, ip, ua, status="success",
                                  login_type="resume", broker=session.get("broker"))
                return resumed

            # No valid broker session — redirect to broker login
            logger.info(f"[LOGIN] No valid broker session, redirecting to /broker")
            from database.auth_db import log_login_attempt
            log_login_attempt(username, ip, ua, status="success", login_type="password")
            return jsonify({"status": "success"}), 200
        else:
            from database.auth_db import log_login_attempt
            log_login_attempt(username, get_real_ip(),
                              request.headers.get("User-Agent", ""),
                              status="failed", login_type="password",
                              failure_reason="invalid_credentials")
            return jsonify({"status": "error", "message": "Invalid credentials"}), 401

    # Handle GET requests - redirect to React frontend
    if find_user_by_username() is None:
        return redirect("/setup")

    if "user" in session:
        return redirect("/broker")

    if session.get("logged_in"):
        return redirect("/dashboard")

    return redirect("/login")


@auth_bp.route("/login/totp", methods=["POST"])
@limiter.limit(LOGIN_RATE_LIMIT_MIN)
@limiter.limit(LOGIN_RATE_LIMIT_HOUR)
def login_totp():
    """Second factor for the dashboard login flow.

    Only reachable after a successful password step on a user that has
    ``totp_required_for_login`` enabled. The password step deliberately
    leaves ``session["user"]`` unset and parks the username on
    ``session["pending_totp_user"]`` so an attacker with only the
    password cannot progress.

    On success: sets ``session["user"]`` and stamps
    ``session["totp_verified_at"]`` so downstream code (notably the
    Phase 2 OAuth ``/oauth/authorize`` endpoint) can require a fresh
    TOTP.
    """
    if not _pending_totp_is_fresh():
        _clear_pending_totp()
        return jsonify(
            {
                "status": "error",
                "message": "Login session expired. Please sign in again.",
                "redirect": "/login",
            }
        ), 401

    pending_username = session.get("pending_totp_user")
    if not pending_username:
        return jsonify({"status": "error", "message": "No pending login. Sign in first."}), 401

    data = request.get_json(silent=True) or {}
    totp_code = (data.get("totp_code") or request.form.get("totp_code") or "").strip()
    if not totp_code:
        return jsonify({"status": "error", "message": "TOTP code is required."}), 400

    user = find_user_by_exact_username(pending_username)
    if user is None or not user.verify_totp(totp_code):
        from database.auth_db import log_login_attempt

        log_login_attempt(
            pending_username,
            get_real_ip(),
            request.headers.get("User-Agent", ""),
            status="failed",
            login_type="totp",
            failure_reason="invalid_totp",
        )
        # Don't clear the pending marker on a single bad code — let the
        # rate limiter handle brute force. The 5-min freshness window
        # caps total attempts anyway.
        return jsonify({"status": "error", "message": "Invalid TOTP code."}), 401

    # Promote the pending login to a real session.
    session["user"] = pending_username
    session["totp_verified_at"] = _utcnow_iso()
    _clear_pending_totp()

    ip = get_real_ip()
    ua = request.headers.get("User-Agent", "")
    from database.auth_db import log_login_attempt

    # Try resuming an existing broker session, same path as plain login.
    resumed = _try_resume_broker_session(pending_username)
    if resumed:
        log_login_attempt(
            pending_username, ip, ua, status="success",
            login_type="totp_resume", broker=session.get("broker"),
        )
        return resumed

    log_login_attempt(pending_username, ip, ua, status="success", login_type="totp")
    return jsonify({"status": "success"}), 200


@auth_bp.route("/2fa/status", methods=["GET"])
@check_session_validity
def two_factor_status():
    """Return the signed-in user's current 2FA configuration."""
    user = find_user_by_exact_username(session["user"])
    if user is None:
        return jsonify({"status": "error", "message": "User not found."}), 404
    return jsonify(
        {
            "status": "success",
            "totp_enabled": bool(user.totp_enabled),
            "totp_required_for_login": bool(user.totp_required_for_login),
            "totp_required_for_mcp": bool(user.totp_required_for_mcp),
            "totp_required_for_password_reset": bool(user.totp_required_for_password_reset),
            "last_totp_verified_at": session.get("totp_verified_at"),
        }
    )


@auth_bp.route("/2fa/configure", methods=["POST"])
@check_session_validity
def two_factor_configure():
    """Enable / disable 2FA and set per-purpose flags atomically.

    The user must verify a current TOTP code in the same request whether
    they are turning the master switch on or off — both transitions are
    sensitive enough to demand proof of TOTP-app access. If the master is
    off in the new state, every per-purpose flag is forced to False as
    well so the stored config is consistent.
    """
    data = request.get_json(silent=True) or {}
    totp_code = (data.get("totp_code") or "").strip()
    if not totp_code:
        return jsonify({"status": "error", "message": "TOTP code is required to change 2FA settings."}), 400

    user = find_user_by_exact_username(session["user"])
    if user is None:
        return jsonify({"status": "error", "message": "User not found."}), 404

    if not user.verify_totp(totp_code):
        return jsonify({"status": "error", "message": "Invalid TOTP code."}), 401

    enabled = bool(data.get("totp_enabled", False))
    # Per-purpose flags are interpreted only when the master is on. When
    # the master is off they are forced False to avoid stale-on-disk
    # configuration that would silently re-engage on the next enable.
    purpose_login = bool(data.get("totp_required_for_login", False)) if enabled else False
    purpose_mcp = bool(data.get("totp_required_for_mcp", False)) if enabled else False
    purpose_reset = bool(data.get("totp_required_for_password_reset", False)) if enabled else False

    user.totp_enabled = enabled
    user.totp_required_for_login = purpose_login
    user.totp_required_for_mcp = purpose_mcp
    user.totp_required_for_password_reset = purpose_reset
    db_session.commit()

    # Stamp the session so any downstream "fresh TOTP" check considers
    # this verification recent. Useful in the same-page UX where a user
    # toggles 2FA and immediately uses an OAuth flow.
    session["totp_verified_at"] = _utcnow_iso()

    logger.info(
        f"[2FA] User {user.username} set enabled={enabled} "
        f"login={purpose_login} mcp={purpose_mcp} reset={purpose_reset}"
    )

    return jsonify(
        {
            "status": "success",
            "totp_enabled": enabled,
            "totp_required_for_login": purpose_login,
            "totp_required_for_mcp": purpose_mcp,
            "totp_required_for_password_reset": purpose_reset,
        }
    )


@auth_bp.route("/broker", methods=["GET", "POST"])
@limiter.limit(LOGIN_RATE_LIMIT_MIN)
@limiter.limit(LOGIN_RATE_LIMIT_HOUR)
def broker_login():
    if session.get("logged_in"):
        return redirect("/dashboard")
    if request.method == "GET":
        if "user" not in session:
            return redirect("/login")

        # Redirect to React broker selection page
        return redirect("/broker")


@auth_bp.route("/reset-password", methods=["GET", "POST"])
@limiter.limit(RESET_RATE_LIMIT)  # Password reset rate limit
def reset_password():
    # GET requests are handled by React frontend - redirect there
    if request.method == "GET":
        return redirect("/reset-password")

    # Handle JSON requests from React frontend
    if request.is_json:
        data = request.get_json()
        step = data.get("step")
        email = data.get("email")
    else:
        # Fall back to form data for compatibility
        step = request.form.get("step")
        email = request.form.get("email")

    # Debug logging for CSRF issues
    logger.debug(f"Password reset step: {step}, Session: {session.keys()}")

    if step == "email":
        user = find_user_by_email(email)

        # Always show the same response to prevent user enumeration
        if user:
            session["reset_email"] = email

        # Return success regardless of whether email exists (prevents enumeration)
        return jsonify({"status": "success", "message": "Email verified"})

    elif step == "select_totp":
        session["reset_method"] = "totp"
        return jsonify({"status": "success", "method": "totp"})

    elif step == "select_email":
        user = find_user_by_email(email)

        # Per-user 2FA gate: when the account has password-reset 2FA enabled,
        # the email path is intentionally unavailable. Forces the TOTP route.
        # The check runs ONLY for known emails — for unknown emails we fall
        # through to the generic "email sent if account exists" response so
        # we don't leak whether the account exists.
        if user is not None and user.is_totp_required_for("password_reset"):
            return jsonify(
                {
                    "status": "error",
                    "message": "This account requires TOTP for password reset. "
                    "Please choose 'Authenticator app' instead.",
                }
            ), 400

        session["reset_method"] = "email"

        # Check if SMTP is configured
        smtp_settings = get_smtp_settings()
        if not smtp_settings or not smtp_settings.get("smtp_server"):
            return jsonify(
                {
                    "status": "error",
                    "message": "Email reset is not available. Please use TOTP authentication.",
                }
            ), 400

        if user:
            try:
                # Generate a secure token for the email reset
                token = secrets.token_urlsafe(32)
                session["reset_token"] = token
                session["reset_email"] = email

                # Create reset link
                reset_link = url_for("auth.reset_password_email", token=token, _external=True)
                send_password_reset_email(email, reset_link, user.username)
                logger.info(f"Password reset email sent to {email}")

            except Exception as e:
                logger.exception(f"Failed to send password reset email to {email}: {e}")
                return jsonify(
                    {
                        "status": "error",
                        "message": "Failed to send reset email. Please try TOTP authentication instead.",
                    }
                ), 500

        # Return success regardless of whether email exists (prevents enumeration)
        return jsonify({"status": "success", "message": "Reset email sent if account exists"})

    elif step == "totp":
        if request.is_json:
            totp_code = data.get("totp_code")
        else:
            totp_code = request.form.get("totp_code")

        user = find_user_by_email(email)

        if user and user.verify_totp(totp_code):
            # Generate a secure token for the password reset
            token = secrets.token_urlsafe(32)
            session["reset_token"] = token
            session["reset_email"] = email

            return jsonify({"status": "success", "message": "TOTP verified", "token": token})
        else:
            return jsonify(
                {"status": "error", "message": "Invalid TOTP code. Please try again."}
            ), 400

    elif step == "password":
        if request.is_json:
            token = data.get("token")
            password = data.get("password")
        else:
            token = request.form.get("token")
            password = request.form.get("password")

        # Verify token from session (handles both TOTP and email reset tokens)
        valid_token = token == session.get("reset_token") or token == session.get(
            "email_reset_token"
        )
        if not valid_token or email != session.get("reset_email"):
            return jsonify({"status": "error", "message": "Invalid or expired reset token."}), 400

        # Validate password strength
        from utils.auth_utils import validate_password_strength

        is_valid, error_message = validate_password_strength(password)
        if not is_valid:
            return jsonify({"status": "error", "message": error_message}), 400

        user = find_user_by_email(email)
        if user:
            user.set_password(password)
            db_session.commit()

            # Security: a password reset means we cannot trust any other
            # active session for this account. Kick every device — the
            # operator (or attacker) chose the reset path because they
            # could prove control of the email/TOTP, not because every
            # logged-in browser is theirs. Force re-login everywhere.
            from database.auth_db import clear_user_sessions
            clear_user_sessions(user.username)
            socketio.emit("force_logout", {
                "message": "Your password was reset. Please log in again with the new password.",
            })

            # Clear reset session data for security
            session.pop("reset_token", None)
            session.pop("reset_email", None)
            session.pop("reset_method", None)
            session.pop("email_reset_token", None)

            return jsonify(
                {"status": "success", "message": "Your password has been reset successfully."}
            )
        else:
            return jsonify({"status": "error", "message": "Error resetting password."}), 400

    return jsonify({"status": "error", "message": "Invalid step"}), 400


@auth_bp.route("/reset-password-email/<token>", methods=["GET"])
def reset_password_email(token):
    """Handle password reset via email link - validates token and redirects to React"""
    try:
        # Validate the token format
        if not token or len(token) != 43:  # URL-safe base64 tokens are 43 chars for 32 bytes
            flash("Invalid reset link.", "error")
            return redirect("/reset-password?error=invalid_link")

        # Check if this token was issued (stored in session during email send)
        if token != session.get("reset_token"):
            flash("Invalid or expired reset link.", "error")
            return redirect("/reset-password?error=expired_link")

        # Get the email associated with this reset token
        reset_email = session.get("reset_email")
        if not reset_email:
            flash("Reset session expired. Please start again.", "error")
            return redirect("/reset-password?error=session_expired")

        # Set up session for password reset (email verification counts as verified)
        session["email_reset_token"] = token

        # Redirect to React password reset page with token and email in URL
        # React will read these and show the password form
        return redirect(f"/reset-password?token={token}&email={reset_email}&verified=true")

    except Exception as e:
        logger.exception(f"Error processing email reset link: {e}")
        flash("Invalid or expired reset link.", "error")
        return redirect("/reset-password?error=processing_error")


@auth_bp.route("/change", methods=["GET", "POST"])
@check_session_validity
def change_password():
    if "user" not in session:
        # If the user is not logged in, redirect to login page
        if request.is_json:
            return jsonify({"status": "error", "message": "Not authenticated"}), 401
        return redirect("/login")

    # GET requests redirect to React profile page
    if request.method == "GET":
        return redirect("/profile")

    # Handle POST requests - change password
    # Support both JSON and form data
    if request.is_json:
        data = request.get_json()
        old_password = data.get("old_password") or data.get("current_password")
        new_password = data.get("new_password")
        confirm_password = data.get("confirm_password", new_password)
    else:
        old_password = request.form.get("old_password") or request.form.get("current_password")
        new_password = request.form.get("new_password")
        confirm_password = request.form.get("confirm_password", new_password)

    username = session["user"]
    user = User.query.filter_by(username=username).first()

    if user and user.check_password(old_password):
        if new_password == confirm_password:
            # Validate password strength
            from utils.auth_utils import validate_password_strength

            is_valid, error_message = validate_password_strength(new_password)
            if not is_valid:
                return jsonify({"status": "error", "message": error_message}), 400

            user.set_password(new_password)
            db_session.commit()

            # Security: a password change is a strong signal of suspected
            # compromise (or routine rotation). Either way, every active
            # session for this account should be re-authenticated. Kick all
            # devices — including the current one — and let the user log
            # in again with the new password. This prevents an attacker
            # who already has a valid cookie from continuing to hold it.
            from database.auth_db import clear_user_sessions
            clear_user_sessions(username)
            socketio.emit("force_logout", {
                "message": "Your password was changed. Please log in again with the new password.",
            })
            session.clear()

            return jsonify(
                {"status": "success", "message": "Your password has been changed successfully."}
            )
        else:
            return jsonify(
                {"status": "error", "message": "New password and confirm password do not match."}
            ), 400
    else:
        return jsonify({"status": "error", "message": "Current password is incorrect."}), 400


@auth_bp.route("/smtp-config", methods=["POST"])
@check_session_validity
def configure_smtp():
    if "user" not in session:
        # For AJAX requests, return JSON
        if request.headers.get("X-Requested-With") == "XMLHttpRequest" or request.is_json:
            return jsonify({"status": "error", "message": "Not authenticated"}), 401
        flash("You must be logged in to configure SMTP settings.", "warning")
        return redirect(url_for("auth.login"))

    try:
        smtp_server = request.form.get("smtp_server")
        smtp_port = int(request.form.get("smtp_port", 587))
        smtp_username = request.form.get("smtp_username")
        smtp_password = request.form.get("smtp_password")
        smtp_use_tls = request.form.get("smtp_use_tls") == "on"
        smtp_from_email = request.form.get("smtp_from_email")
        smtp_helo_hostname = request.form.get("smtp_helo_hostname")

        # Only update password if provided
        if smtp_password and smtp_password.strip():
            set_smtp_settings(
                smtp_server=smtp_server,
                smtp_port=smtp_port,
                smtp_username=smtp_username,
                smtp_password=smtp_password,
                smtp_use_tls=smtp_use_tls,
                smtp_from_email=smtp_from_email,
                smtp_helo_hostname=smtp_helo_hostname,
            )
        else:
            # Update without password change
            set_smtp_settings(
                smtp_server=smtp_server,
                smtp_port=smtp_port,
                smtp_username=smtp_username,
                smtp_use_tls=smtp_use_tls,
                smtp_from_email=smtp_from_email,
                smtp_helo_hostname=smtp_helo_hostname,
            )

        logger.info(f"SMTP settings updated by user: {session['user']}")

        # For AJAX requests, return JSON
        if (
            request.headers.get("X-Requested-With") == "XMLHttpRequest"
            or request.is_json
            or "multipart/form-data" in request.content_type
        ):
            return jsonify({"status": "success", "message": "SMTP settings updated successfully"})

        flash("SMTP settings updated successfully.", "success")

    except Exception as e:
        logger.exception(f"Error updating SMTP settings: {str(e)}")
        # For AJAX requests, return JSON
        if request.headers.get("X-Requested-With") == "XMLHttpRequest" or request.is_json:
            return jsonify(
                {"status": "error", "message": f"Error updating SMTP settings: {str(e)}"}
            ), 500
        flash(f"Error updating SMTP settings: {str(e)}", "error")

    return redirect(url_for("auth.change_password") + "?tab=smtp")


@auth_bp.route("/test-smtp", methods=["POST"])
@check_session_validity
def test_smtp():
    if "user" not in session:
        return jsonify(
            {"success": False, "message": "You must be logged in to test SMTP settings."}
        ), 401

    try:
        test_email = request.form.get("test_email")
        if not test_email:
            return jsonify(
                {"success": False, "message": "Please provide a test email address."}
            ), 400

        # Validate email format
        email_pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        if not re.match(email_pattern, test_email):
            return jsonify(
                {"success": False, "message": "Please provide a valid email address."}
            ), 400

        # Send test email
        result = send_test_email(test_email, sender_name=session["user"])

        if result["success"]:
            logger.info(f"Test email sent successfully by user: {session['user']} to {test_email}")
            return jsonify({"success": True, "message": result["message"]}), 200
        else:
            logger.warning(f"Test email failed for user: {session['user']} - {result['message']}")
            return jsonify({"success": False, "message": result["message"]}), 400

    except Exception as e:
        error_msg = f"Error sending test email: {str(e)}"
        logger.exception(f"Test email error for user {session['user']}: {e}")
        return jsonify({"success": False, "message": error_msg}), 500


@auth_bp.route("/debug-smtp", methods=["POST"])
@check_session_validity
def debug_smtp():
    if "user" not in session:
        return jsonify(
            {"success": False, "message": "You must be logged in to debug SMTP settings."}
        ), 401

    try:
        logger.info(f"SMTP debug requested by user: {session['user']}")
        result = debug_smtp_connection()

        return jsonify(
            {
                "success": result["success"],
                "message": result["message"],
                "details": result["details"],
            }
        ), 200

    except Exception as e:
        error_msg = f"Error debugging SMTP: {str(e)}"
        logger.exception(f"SMTP debug error for user {session['user']}: {e}")
        return jsonify(
            {"success": False, "message": error_msg, "details": [f"Unexpected error: {e}"]}
        ), 500


@auth_bp.route("/session-status", methods=["GET"])
def get_session_status():
    """Return current session status for React SPA."""
    if "user" not in session:
        # Return 200 with authenticated: false instead of 401
        # This prevents unnecessary console errors in the browser
        return jsonify(
            {"status": "success", "message": "Not authenticated", "authenticated": False, "logged_in": False}
        ), 200

    # If session claims to be logged in with broker, validate the auth token exists
    if session.get("logged_in") and session.get("broker"):
        from database.auth_db import get_api_key_for_tradingview, get_auth_token

        auth_token = get_auth_token(session.get("user"))
        if auth_token is None:
            logger.warning(
                f"Session status: stale session detected for user {session.get('user')} - no auth token"
            )
            # Clear the stale session
            session.clear()
            return jsonify(
                {"status": "success", "message": "Session expired", "authenticated": False, "logged_in": False}
            ), 200

        # Get API key for the user
        api_key = get_api_key_for_tradingview(session.get("user"))

        # Include active session count
        from database.auth_db import get_active_sessions
        active_count = len(get_active_sessions(session.get("user")))

        return jsonify(
            {
                "status": "success",
                "authenticated": True,
                "logged_in": session.get("logged_in", False),
                "user": session.get("user"),
                "broker": session.get("broker"),
                "api_key": api_key,
                "active_sessions": active_count,
            }
        )

    # Include active session count
    from database.auth_db import get_active_sessions
    active_count = len(get_active_sessions(session.get("user")))

    return jsonify(
        {
            "status": "success",
            "authenticated": True,
            "logged_in": session.get("logged_in", False),
            "user": session.get("user"),
            "broker": session.get("broker"),
            "active_sessions": active_count,
        }
    )


@auth_bp.route("/active-sessions", methods=["GET"])
@check_session_validity
def active_sessions():
    """Return the list of active sessions for the current user."""
    if "user" not in session:
        return jsonify({"status": "error", "message": "Not authenticated"}), 401

    from database.auth_db import get_active_sessions
    sessions = get_active_sessions(session["user"])
    current_session_id = session.get("session_id")

    return jsonify({
        "status": "success",
        "count": len(sessions),
        "current_session_id": current_session_id,
        "sessions": sessions,
    })


@auth_bp.route("/app-info", methods=["GET"])
def get_app_info():
    """Return app information including version for React SPA."""
    from utils.version import get_version

    return jsonify({"status": "success", "version": get_version(), "name": "OpenAlgo"})


@auth_bp.route("/analyzer-mode", methods=["GET"])
@check_session_validity
def get_analyzer_mode_status():
    """Return current analyzer mode status for React SPA."""
    if "user" not in session:
        return jsonify({"status": "error", "message": "Not authenticated"}), 401

    try:
        from database.settings_db import get_analyze_mode

        current_mode = get_analyze_mode()

        return jsonify(
            {
                "status": "success",
                "data": {
                    "mode": "analyze" if current_mode else "live",
                    "analyze_mode": current_mode,
                },
            }
        )
    except Exception as e:
        logger.exception(f"Error getting analyzer mode: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@auth_bp.route("/analyzer-toggle", methods=["POST"])
@check_session_validity
def toggle_analyzer_mode_session():
    """Toggle analyzer mode for React SPA using session authentication."""
    if "user" not in session:
        return jsonify({"status": "error", "message": "Not authenticated"}), 401

    if not session.get("logged_in"):
        return jsonify({"status": "error", "message": "Broker not connected"}), 401

    try:
        from database.settings_db import get_analyze_mode, set_analyze_mode

        # Get current mode and toggle it
        current_mode = get_analyze_mode()
        new_mode = not current_mode

        # Set the new mode
        set_analyze_mode(new_mode)

        # Start/stop execution engine and squareoff scheduler based on mode
        from sandbox.execution_thread import start_execution_engine, stop_execution_engine
        from sandbox.squareoff_thread import start_squareoff_scheduler, stop_squareoff_scheduler

        if new_mode:
            # Analyzer mode ON - start both threads
            start_execution_engine()
            start_squareoff_scheduler()

            # Run catch-up settlement for any missed settlements while app was stopped
            from sandbox.position_manager import catchup_missed_settlements

            try:
                catchup_missed_settlements()
                logger.info("Catch-up settlement check completed")
            except Exception as e:
                logger.exception(f"Error in catch-up settlement: {e}")

            logger.info("Analyzer mode enabled - Execution engine and square-off scheduler started")
        else:
            # Analyzer mode OFF - stop both threads
            stop_execution_engine()
            stop_squareoff_scheduler()
            logger.info(
                "Analyzer mode disabled - Execution engine and square-off scheduler stopped"
            )

        return jsonify(
            {
                "status": "success",
                "data": {
                    "mode": "analyze" if new_mode else "live",
                    "analyze_mode": new_mode,
                    "message": f"Switched to {'Analyze' if new_mode else 'Live'} mode",
                },
            }
        )

    except Exception as e:
        logger.exception(f"Error toggling analyzer mode: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@auth_bp.route("/dashboard-data", methods=["GET"])
@check_session_validity
def get_dashboard_data():
    """Return dashboard funds data using session authentication for React SPA."""
    if "user" not in session:
        return jsonify({"status": "error", "message": "Not authenticated"}), 401

    if not session.get("logged_in"):
        return jsonify({"status": "error", "message": "Broker not connected"}), 401

    login_username = session["user"]
    broker = session.get("broker")

    if not broker:
        return jsonify({"status": "error", "message": "Broker not set in session"}), 400

    try:
        from database.auth_db import get_api_key_for_tradingview, get_auth_token
        from database.settings_db import get_analyze_mode
        from services.funds_service import get_funds

        AUTH_TOKEN = get_auth_token(login_username)

        if AUTH_TOKEN is None:
            logger.warning(f"No auth token found for user {login_username}")
            return jsonify({"status": "error", "message": "Session expired"}), 401

        # Check if in analyze mode
        if get_analyze_mode():
            api_key = get_api_key_for_tradingview(login_username)
            if api_key:
                success, response, status_code = get_funds(api_key=api_key)
            else:
                return jsonify(
                    {"status": "error", "message": "API key required for analyze mode"}
                ), 400
        else:
            success, response, status_code = get_funds(auth_token=AUTH_TOKEN, broker=broker)

        if not success:
            logger.error(f"Failed to get funds data: {response.get('message', 'Unknown error')}")
            return jsonify(
                {"status": "error", "message": response.get("message", "Failed to get funds")}
            ), status_code

        margin_data = response.get("data", {})

        if not margin_data:
            logger.error(f"Failed to get margin data for user {login_username}")
            return jsonify({"status": "error", "message": "Failed to get margin data"}), 500

        return jsonify({"status": "success", "data": margin_data})

    except Exception as e:
        logger.exception(f"Error fetching dashboard data: {e}")
        return jsonify({"status": "error", "message": "Internal server error"}), 500


@auth_bp.route("/logout", methods=["GET", "POST"])
def logout():
    if session.get("logged_in"):
        username = session["user"]

        # Clear cache entries before database update to prevent stale data access
        cache_key_auth = f"auth-{username}"
        cache_key_feed = f"feed-{username}"
        if cache_key_auth in auth_cache:
            del auth_cache[cache_key_auth]
            logger.info(f"Cleared auth cache for user: {username}")
        if cache_key_feed in feed_token_cache:
            del feed_token_cache[cache_key_feed]
            logger.info(f"Cleared feed token cache for user: {username}")

        # Clear symbol cache on logout
        try:
            from database.master_contract_cache_hook import clear_cache_on_logout

            clear_cache_on_logout()
            logger.info("Cleared symbol cache on logout")
        except Exception as cache_error:
            logger.exception(f"Error clearing symbol cache on logout: {cache_error}")

        # writing to database
        inserted_id = upsert_auth(username, "", "", revoke=True)
        if inserted_id is not None:
            logger.info(f"Database Upserted record with ID: {inserted_id}")
            logger.info(f"Auth Revoked in the Database for user: {username}")
        else:
            logger.error(f"Failed to upsert auth token for user: {username}")

        # Clear ALL sessions for this user (logout means all devices)
        from database.auth_db import clear_user_sessions
        clear_user_sessions(username)

        # Notify all connected devices to logout immediately
        socketio.emit("force_logout", {
            "message": "You have been logged out from another device.",
        })

        # Update session count to 0
        socketio.emit("active_sessions_update", {
            "count": 0,
            "sessions": [],
        })

        # Clear entire session to ensure complete logout
        session.clear()
        logger.info(f"Session cleared for user: {username}")

    # For POST requests (AJAX from React), return JSON
    if request.method == "POST":
        return jsonify({"status": "success", "message": "Logged out successfully"})

    # For GET requests (traditional), redirect to login page
    return redirect(url_for("auth.login"))


@auth_bp.route("/profile-data", methods=["GET"])
@check_session_validity
def get_profile_data():
    """Return profile data for React SPA."""
    if "user" not in session:
        return jsonify({"status": "error", "message": "Not authenticated"}), 401

    username = session["user"]

    try:
        # Get SMTP settings
        smtp_settings = get_smtp_settings()

        # Mask SMTP password - just indicate if it's set
        if smtp_settings and smtp_settings.get("smtp_password"):
            smtp_settings = dict(smtp_settings)
            smtp_settings["smtp_password"] = True
        elif smtp_settings:
            smtp_settings = dict(smtp_settings)
            smtp_settings["smtp_password"] = False

        # Generate TOTP QR code
        user = User.query.filter_by(username=username).first()
        qr_code = None
        totp_secret = None

        if user:
            try:
                import base64
                import io

                import qrcode

                qr = qrcode.QRCode(version=1, box_size=10, border=5)
                qr.add_data(user.get_totp_uri())
                qr.make(fit=True)

                img_buffer = io.BytesIO()
                qr.make_image(fill_color="black", back_color="white").save(img_buffer, format="PNG")
                qr_code = base64.b64encode(img_buffer.getvalue()).decode()
                # Use the public getter that decrypts the at-rest ciphertext.
                # `user.totp_secret` is the raw column value (ciphertext);
                # `get_totp_secret()` returns the plaintext with a fallback
                # for pre-migration rows.
                totp_secret = user.get_totp_secret()
            except Exception as e:
                logger.exception(f"Error generating TOTP QR code: {e}")

        return jsonify(
            {
                "status": "success",
                "data": {
                    "username": username,
                    "smtp_settings": smtp_settings,
                    "qr_code": qr_code,
                    "totp_secret": totp_secret,
                },
            }
        )

    except Exception as e:
        logger.exception(f"Error getting profile data: {e}")
        return jsonify({"status": "error", "message": "Failed to get profile data"}), 500


@auth_bp.route("/change-password", methods=["POST"])
@check_session_validity
def change_password_api():
    """Change password API endpoint for React SPA."""
    if "user" not in session:
        return jsonify({"status": "error", "message": "Not authenticated"}), 401

    username = session["user"]
    old_password = request.form.get("old_password")
    new_password = request.form.get("new_password")
    confirm_password = request.form.get("confirm_password")

    if not all([old_password, new_password, confirm_password]):
        return jsonify({"status": "error", "message": "All fields are required"}), 400

    user = User.query.filter_by(username=username).first()

    if not user or not user.check_password(old_password):
        return jsonify({"status": "error", "message": "Current password is incorrect"}), 400

    if new_password != confirm_password:
        return jsonify({"status": "error", "message": "New passwords do not match"}), 400

    # Validate password strength
    from utils.auth_utils import validate_password_strength

    is_valid, error_message = validate_password_strength(new_password)
    if not is_valid:
        return jsonify({"status": "error", "message": error_message}), 400

    try:
        user.set_password(new_password)
        db_session.commit()
        logger.info(f"Password changed successfully for user: {username}")

        # Security: a password change should invalidate every active session
        # for this account, including the current browser. The user logs in
        # again with the new password — typical 5-second flow — and any
        # attacker holding a stolen cookie is kicked out at the same moment.
        from database.auth_db import clear_user_sessions
        clear_user_sessions(username)
        socketio.emit("force_logout", {
            "message": "Your password was changed. Please log in again with the new password.",
        })
        session.clear()

        return jsonify({"status": "success", "message": "Password changed successfully"})
    except Exception as e:
        logger.exception(f"Error changing password: {e}")
        return jsonify({"status": "error", "message": "Failed to change password"}), 500
