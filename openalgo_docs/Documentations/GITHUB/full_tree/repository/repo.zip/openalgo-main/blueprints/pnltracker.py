import threading
import time as time_module
from datetime import datetime, timedelta
from datetime import time as dt_time
from importlib import import_module

import numpy as np
import pandas as pd
import pytz
from flask import Blueprint, jsonify, redirect, render_template, request, session, url_for
from flask_cors import cross_origin

from database.auth_db import get_api_key_for_tradingview, get_auth_token
from services.history_service import get_history
from services.tradebook_service import get_tradebook
from utils.logging import get_logger
from utils.session import check_session_validity

logger = get_logger(__name__)


def parse_trade_timestamp(timestamp_str, fallback_date=None):
    """
    Safely parse trade timestamp from various broker formats.

    Supported formats:
    - "17-Dec-2025 10:54:03" (AngelOne)
    - "09:41:01 17-12-2025" (Flattrade)
    - "10:30:52" (Time only)
    - Unix timestamp (int/float)
    - ISO format strings

    Returns: timezone-aware datetime in IST, or None if parsing fails
    """
    ist = pytz.timezone("Asia/Kolkata")

    if timestamp_str is None:
        return None

    # Handle numeric timestamps (Unix epoch)
    if isinstance(timestamp_str, (int, float)):
        try:
            dt = pd.to_datetime(timestamp_str, unit="s")
            if dt.tz is None:
                return dt.tz_localize("UTC").tz_convert(ist)
            return dt.tz_convert(ist)
        except Exception as e:
            logger.warning(f"Failed to parse numeric timestamp {timestamp_str}: {e}")
            return None

    if not isinstance(timestamp_str, str):
        return None

    timestamp_str = timestamp_str.strip()
    if not timestamp_str:
        return None

    # List of formats to try (order matters - more specific first)
    formats = [
        "%d-%b-%Y %H:%M:%S",  # AngelOne: "17-Dec-2025 10:54:03"
        "%H:%M:%S %d-%m-%Y",  # Flattrade: "09:41:01 17-12-2025"
        "%d-%m-%Y %H:%M:%S",  # "17-12-2025 09:41:01"
        "%Y-%m-%d %H:%M:%S",  # ISO-like: "2025-12-17 10:30:00"
        "%Y-%m-%dT%H:%M:%S",  # ISO: "2025-12-17T10:30:00"
    ]

    for fmt in formats:
        try:
            dt = datetime.strptime(timestamp_str, fmt)
            return ist.localize(dt)
        except ValueError:
            continue

    # Try time-only format: "HH:MM:SS"
    if ":" in timestamp_str and " " not in timestamp_str:
        try:
            time_parts = timestamp_str.split(":")
            if len(time_parts) >= 2 and len(time_parts[0]) <= 2:
                today = fallback_date or datetime.now(ist).date()
                dt = datetime.combine(
                    today,
                    dt_time(
                        int(time_parts[0]),
                        int(time_parts[1]),
                        int(time_parts[2]) if len(time_parts) > 2 else 0,
                    ),
                )
                return ist.localize(dt)
        except (ValueError, IndexError):
            pass

    # Fallback: try pandas auto-parsing
    try:
        dt = pd.to_datetime(timestamp_str)
        if dt.tz is None:
            return dt.tz_localize(ist)
        return dt.tz_convert(ist)
    except Exception as e:
        logger.warning(f"Failed to auto-parse timestamp '{timestamp_str}': {e}")

    return None


# Rate limiter for historical data API calls
class RateLimiter:
    """Thread-safe rate limiter for API calls"""

    def __init__(self, calls_per_second=2):
        self.calls_per_second = calls_per_second
        self.min_interval = 1.0 / calls_per_second  # Time between calls
        self.last_call_time = 0
        self.lock = threading.Lock()

    def wait(self):
        """Wait if necessary to respect rate limit"""
        with self.lock:
            current_time = time_module.time()
            elapsed = current_time - self.last_call_time
            if elapsed < self.min_interval:
                sleep_time = self.min_interval - elapsed
                time_module.sleep(sleep_time)
            self.last_call_time = time_module.time()


# Global rate limiter instance - 2 calls per second (conservative limit)
history_rate_limiter = RateLimiter(calls_per_second=2)

# Define the blueprint
pnltracker_bp = Blueprint("pnltracker_bp", __name__, url_prefix="/")


def convert_timestamp_to_ist(df, symbol=""):
    """
    Convert timestamp to IST with robust handling for different formats.
    Returns the dataframe with datetime index in IST timezone.
    """
    ist = pytz.timezone("Asia/Kolkata")

    try:
        # Try different timestamp formats
        if "timestamp" in df.columns:
            # Try as Unix timestamp first (seconds)
            try:
                df["datetime"] = pd.to_datetime(df["timestamp"], unit="s", utc=True)
                df["datetime"] = df["datetime"].dt.tz_convert(ist)
            except Exception:
                # Try as milliseconds
                try:
                    df["datetime"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
                    df["datetime"] = df["datetime"].dt.tz_convert(ist)
                except Exception:
                    # Try as string datetime
                    df["datetime"] = pd.to_datetime(df["timestamp"])
                    if df["datetime"].dt.tz is None:
                        df["datetime"] = df["datetime"].dt.tz_localize("UTC").dt.tz_convert(ist)
                    else:
                        df["datetime"] = df["datetime"].dt.tz_convert(ist)
        elif "datetime" in df.columns:
            df["datetime"] = pd.to_datetime(df["datetime"])
            if df["datetime"].dt.tz is None:
                df["datetime"] = df["datetime"].dt.tz_localize("UTC").dt.tz_convert(ist)
            else:
                df["datetime"] = df["datetime"].dt.tz_convert(ist)
        else:
            logger.warning(f"No timestamp field found for {symbol}")
            return None

        df.set_index("datetime", inplace=True)
        df = df.sort_index()
        return df
    except Exception as e:
        logger.warning(f"Error converting timestamps for {symbol}: {e}")
        return None


def dynamic_import(broker, module_name, function_names):
    module_functions = {}
    try:
        # Import the module based on the broker name
        module = import_module(f"broker.{broker}.{module_name}")
        for name in function_names:
            module_functions[name] = getattr(module, name)
        return module_functions
    except (ImportError, AttributeError) as e:
        logger.error(
            f"Error importing functions {function_names} from {module_name} for broker {broker}: {e}"
        )
        return None


# Note: /pnltracker route is now handled by react_bp for React frontend
# This route is kept for backwards compatibility but renamed
@pnltracker_bp.route("/pnltracker/legacy")
@check_session_validity
def pnltracker():
    """Render the PnL tracker page (legacy Jinja template)."""
    return render_template("pnltracker.html")


@pnltracker_bp.route("/test_chart")
def test_chart():
    """Test page for LightWeight Charts."""
    return render_template("test_chart.html")


@pnltracker_bp.route("/pnltracker/api/pnl", methods=["POST"])
@cross_origin()
@check_session_validity
def get_pnl_data():
    """Get intraday PnL data."""
    try:
        broker = session.get("broker")
        if not broker:
            logger.error("Broker not set in session")
            return jsonify({"status": "error", "message": "Broker not set in session"}), 400

        # Get auth token from session - same as orders.py
        login_username = session["user"]
        auth_token = get_auth_token(login_username)

        if auth_token is None:
            logger.warning(f"No auth token found for user {login_username}")
            return jsonify({"status": "error", "message": "Authentication required"}), 401

        # Get API key for the user (for services)
        api_key = get_api_key_for_tradingview(login_username)
        if not api_key:
            logger.warning(f"No API key found for user {login_username}")
            return jsonify(
                {
                    "status": "error",
                    "message": "API key not configured. Please generate an API key in /apikey",
                }
            ), 401

        # Default to today's date for historical data (will be overridden by trade date if trades exist)
        ist = pytz.timezone("Asia/Kolkata")
        today_str = datetime.now(ist).date().strftime("%Y-%m-%d")

        # Get tradebook data using the service (with API key)
        success, tradebook_response, status_code = get_tradebook(api_key=api_key)

        if not success:
            logger.error(f"Error fetching tradebook: {tradebook_response}")
            return jsonify(tradebook_response), status_code

        trades = tradebook_response.get("data", [])

        # Log trades for debugging
        logger.info(f"Number of trades: {len(trades)}")
        if trades and len(trades) > 0:
            logger.info(f"Sample trade: {trades[0]}")

        # Get current positions using positionbook service (handles sandbox mode)
        from services.positionbook_service import get_positionbook

        current_positions = {}
        try:
            success, positions_response, _ = get_positionbook(api_key=api_key)

            if success and "data" in positions_response:
                positions_data = positions_response.get("data", [])

                # Store current positions for reference
                logger.info(f"Number of positions: {len(positions_data) if positions_data else 0}")
                for pos in positions_data:
                    key = f"{pos['symbol']}_{pos['exchange']}"
                    # Convert string values to float if needed
                    try:
                        qty = float(pos.get("quantity", 0))
                        avg_price = float(pos.get("average_price", 0))
                        ltp = float(pos.get("ltp", 0))
                        pnl = float(pos.get("pnl", 0))
                    except (ValueError, TypeError):
                        logger.warning(f"Error converting position values to float for {key}")
                        qty = 0
                        avg_price = 0
                        ltp = 0
                        pnl = 0

                    current_positions[key] = {
                        "quantity": qty,
                        "average_price": avg_price,
                        "ltp": ltp,
                        "pnl": pnl,
                    }
                    logger.info(f"Position {key}: qty={qty}, avg={avg_price}, ltp={ltp}, pnl={pnl}")
            else:
                logger.warning(f"Could not fetch positions: {positions_response}")
        except Exception as e:
            logger.warning(f"Error fetching positions: {e}")
            # Continue without positions data

        if not trades and not current_positions:
            # No trades or positions, return zero PnL
            return jsonify(
                {
                    "status": "success",
                    "data": {
                        "current_mtm": 0,
                        "max_mtm": 0,
                        "max_mtm_time": None,
                        "min_mtm": 0,
                        "min_mtm_time": None,
                        "max_drawdown": 0,
                        "pnl_series": [],
                        "drawdown_series": [],
                    },
                }
            ), 200

        # Process trades to build portfolio MTM
        portfolio_pnl = None
        first_trade_time = None

        # Find the earliest trade time
        for trade in trades:
            trade_timestamp = (
                trade.get("timestamp") or trade.get("fill_timestamp") or trade.get("fill_time")
            )
            if trade_timestamp:
                trade_time = parse_trade_timestamp(trade_timestamp)
                if trade_time:
                    if first_trade_time is None or trade_time < first_trade_time:
                        first_trade_time = trade_time
                        logger.info(
                            f"Found trade at {trade_time.strftime('%H:%M:%S')} for {trade['symbol']}"
                        )
                else:
                    logger.warning(f"Could not parse trade timestamp {trade_timestamp}")

        # If we couldn't determine first trade time from timestamps, try from fill_time field
        if first_trade_time is None and trades:
            for trade in trades:
                fill_time_str = trade.get("fill_time", "")
                if fill_time_str:
                    trade_time = parse_trade_timestamp(fill_time_str)
                    if trade_time:
                        if first_trade_time is None or trade_time < first_trade_time:
                            first_trade_time = trade_time
                            logger.info(
                                f"Found trade at {trade_time.strftime('%H:%M:%S')} from fill_time for {trade['symbol']}"
                            )
                    else:
                        logger.warning(f"Could not parse fill_time {fill_time_str}")

        # Log the first trade time
        if first_trade_time:
            logger.info(f"First trade time: {first_trade_time.strftime('%Y-%m-%d %H:%M:%S %Z')}")
        else:
            logger.warning("Could not determine first trade time, using market open time")
            ist = pytz.timezone("Asia/Kolkata")
            first_trade_time = datetime.now(ist).replace(hour=9, minute=15, second=0, microsecond=0)

        # Determine the trading date from first trade time (handles overnight session spanning)
        # This ensures we query historical data for the correct date when trades are from previous day
        trade_date = first_trade_time.date()
        today_str = trade_date.strftime("%Y-%m-%d")
        logger.info(f"Using trade date for historical data: {today_str}")

        # Group trades by symbol to track entry and exit
        symbol_trades = {}
        for trade in trades:
            try:
                symbol = trade.get("symbol", "")
                exchange = trade.get("exchange", "")
                if not symbol or not exchange:
                    logger.warning(f"Trade missing symbol or exchange: {trade}")
                    continue

                symbol_key = f"{symbol}_{exchange}"
                if symbol_key not in symbol_trades:
                    symbol_trades[symbol_key] = []

                # Parse trade time using universal parser
                trade_timestamp = (
                    trade.get("timestamp") or trade.get("fill_timestamp") or trade.get("fill_time")
                )
                trade_time = parse_trade_timestamp(trade_timestamp) if trade_timestamp else None
                if trade_timestamp and trade_time is None:
                    logger.warning(
                        f"Could not parse trade time for {trade['symbol']}: {trade_timestamp}"
                    )

                trade["parsed_time"] = trade_time
                symbol_trades[symbol_key].append(trade)
            except Exception as e:
                logger.exception(f"Error processing trade: {e}, trade: {trade}")
                continue

        # Process each symbol's trades
        for symbol_key, trades_list in symbol_trades.items():
            if not trades_list:
                logger.warning(f"No trades found for {symbol_key}")
                continue

            # Sort trades by time
            trades_list.sort(
                key=lambda x: x.get("parsed_time") or datetime.min.replace(tzinfo=pytz.UTC)
            )

            symbol = trades_list[0].get("symbol", "")
            exchange = trades_list[0].get("exchange", "")

            if not symbol or not exchange:
                logger.warning(f"Missing symbol or exchange for {symbol_key}")
                continue

            # Track net position and time windows
            net_position = 0
            position_windows = []  # List of (start_time, end_time, qty, price, action)

            for trade in trades_list:
                try:
                    executed_price = float(trade.get("average_price", 0))
                    action = trade.get("action", "")
                    trade_time = trade.get("parsed_time")

                    # Calculate quantity
                    qty = float(trade.get("quantity", 0))
                    if qty == 0 and executed_price > 0:
                        trade_value = float(trade.get("trade_value", 0))
                        if trade_value == executed_price:
                            qty = 1
                        elif trade_value > 0:
                            qty = trade_value / executed_price

                    if qty <= 0:
                        logger.warning(f"Skipping trade with zero/negative quantity: {trade}")
                        continue
                except (TypeError, ValueError) as e:
                    logger.warning(f"Error parsing trade values: {e}, trade: {trade}")
                    continue

                # Track position windows
                if action == "BUY":
                    position_windows.append(
                        {
                            "start_time": trade_time,
                            "end_time": None,  # Will be filled when position is closed
                            "qty": qty,
                            "price": executed_price,
                            "action": "BUY",
                            "exit_price": None,  # Will be filled when position is closed
                        }
                    )
                    net_position += qty
                else:  # SELL
                    # Check if this closes a position
                    if net_position > 0:
                        # This is closing a long position
                        remaining_qty = qty
                        for window in position_windows:
                            if (
                                window["action"] == "BUY"
                                and window["end_time"] is None
                                and remaining_qty > 0
                            ):
                                # Close this position window
                                close_qty = min(window["qty"], remaining_qty)
                                if close_qty == window["qty"]:
                                    window["end_time"] = trade_time
                                    window["exit_price"] = (
                                        executed_price  # Store the actual exit price
                                    )
                                else:
                                    # Partial close - split the window
                                    window["qty"] -= close_qty
                                    # Create a closed window for the partial
                                    closed_window = window.copy()
                                    closed_window["qty"] = close_qty
                                    closed_window["end_time"] = trade_time
                                    closed_window["exit_price"] = (
                                        executed_price  # Store the actual exit price
                                    )
                                    position_windows.append(closed_window)
                                remaining_qty -= close_qty
                        net_position -= qty
                    else:
                        # This is a short position
                        position_windows.append(
                            {
                                "start_time": trade_time,
                                "end_time": None,
                                "qty": qty,
                                "price": executed_price,
                                "action": "SELL",
                                "exit_price": None,
                            }
                        )
                        net_position -= qty

            # Now get historical data and calculate PnL for each position window
            try:
                # Apply rate limiting before API call (2 calls/sec to stay under broker's 3/sec limit)
                history_rate_limiter.wait()
                logger.debug(f"Fetching historical data for {symbol} on {exchange}")

                success, hist_response, _ = get_history(
                    symbol=symbol,
                    exchange=exchange,
                    interval="1m",
                    start_date=today_str,
                    end_date=today_str,
                    api_key=api_key,
                )

                if success and "data" in hist_response:
                    df_hist = pd.DataFrame(hist_response["data"])
                    if not df_hist.empty:
                        df_hist = convert_timestamp_to_ist(df_hist, symbol)

                        if df_hist is not None:
                            ist = pytz.timezone("Asia/Kolkata")
                            current_time = datetime.now(ist)

                            # Filter to trading hours
                            if first_trade_time:
                                df_hist = df_hist[df_hist.index >= first_trade_time]
                            df_hist = df_hist[df_hist.index <= current_time]

                            df_hist = df_hist[["close"]].copy()
                            df_hist.rename(columns={"close": f"{symbol}_price"}, inplace=True)

                            # Initialize PnL column
                            df_hist[f"{symbol}_pnl"] = 0.0

                            # Track cumulative realized PnL
                            cumulative_realized_pnl = 0.0

                            # Sort position windows by start time
                            position_windows_sorted = sorted(
                                position_windows,
                                key=lambda x: x["start_time"]
                                if x["start_time"]
                                else datetime.min.replace(tzinfo=pytz.UTC),
                            )

                            # Calculate PnL for each position window
                            for window in position_windows_sorted:
                                if window["start_time"] is None:
                                    continue

                                # Determine the time range for this position
                                start = window["start_time"]
                                end = window["end_time"] if window["end_time"] else current_time

                                # Create mask for this time window
                                mask = (df_hist.index >= start) & (df_hist.index <= end)

                                # Handle sub-minute trades: if position is closed with entry/exit prices,
                                # calculate realized PnL even if no historical data points exist in the window
                                has_data_points = mask.any()
                                is_closed_position = (
                                    window["end_time"] is not None
                                    and window.get("exit_price") is not None
                                )

                                if not has_data_points and not is_closed_position:
                                    # Skip only if no data points AND position is still open
                                    logger.warning(
                                        f"No data points found for open position window from {start} to {end}"
                                    )
                                    continue

                                # Calculate mark-to-market PnL for this window (only if we have data points)
                                if has_data_points:
                                    if window["action"] == "BUY":
                                        position_pnl = (
                                            df_hist.loc[mask, f"{symbol}_price"] - window["price"]
                                        ) * window["qty"]
                                        df_hist.loc[mask, f"{symbol}_pnl"] += position_pnl
                                    else:  # SELL
                                        position_pnl = (
                                            window["price"] - df_hist.loc[mask, f"{symbol}_price"]
                                        ) * window["qty"]
                                        df_hist.loc[mask, f"{symbol}_pnl"] += position_pnl

                                # Calculate realized PnL for closed positions using actual entry/exit prices
                                # This works even for sub-minute trades without historical data points
                                if is_closed_position:
                                    if window["action"] == "BUY":
                                        realized = (
                                            window["exit_price"] - window["price"]
                                        ) * window["qty"]
                                    else:  # SELL
                                        realized = (
                                            window["price"] - window["exit_price"]
                                        ) * window["qty"]

                                    cumulative_realized_pnl += realized
                                    logger.info(
                                        f"Closed {window['action']} position: entry={window['price']}, exit={window['exit_price']}, "
                                        f"qty={window['qty']}, realized PnL={realized}"
                                        f"{' (sub-minute trade)' if not has_data_points else ''}"
                                    )

                                # After a position is closed, set the cumulative realized PnL for all future timestamps
                                # IMPORTANT: Always update even when cumulative is 0 (e.g., when +225 and -225 cancel out)
                                # Otherwise the previous non-zero value remains in the dataframe
                                if window["end_time"] is not None:
                                    future_mask = df_hist.index > window["end_time"]
                                    if future_mask.any():
                                        df_hist.loc[future_mask, f"{symbol}_pnl"] = (
                                            cumulative_realized_pnl
                                        )
                                    elif cumulative_realized_pnl != 0:
                                        # Edge case: trade closed at/after last candle (e.g., near market close)
                                        # Add realized PnL to the last available candle (only if non-zero)
                                        if len(df_hist) > 0:
                                            last_idx = df_hist.index[-1]
                                            df_hist.loc[last_idx, f"{symbol}_pnl"] = (
                                                cumulative_realized_pnl
                                            )
                                            logger.info(
                                                f"Sub-minute trade near market close: added realized PnL to last candle {last_idx}"
                                            )

                                logger.info(
                                    f"Position window for {symbol}: {window['action']} {window['qty']} @ {window['price']}, "
                                    f"from {start.strftime('%H:%M:%S') if start else 'None'} "
                                    f"to {end.strftime('%H:%M:%S') if end else 'current'}"
                                    f"{' (no historical data in window)' if not has_data_points else ''}"
                                )

                            # Add to portfolio
                            if portfolio_pnl is None:
                                portfolio_pnl = df_hist[[f"{symbol}_pnl"]].copy()
                            else:
                                portfolio_pnl = portfolio_pnl.join(
                                    df_hist[[f"{symbol}_pnl"]], how="outer"
                                )

                            logger.info(f"Added PnL for {symbol}: {len(df_hist)} data points")
                        else:
                            logger.warning(f"Timestamp conversion failed for {symbol}")
                else:
                    logger.warning(f"Could not get historical data for {symbol}")

            except Exception as e:
                logger.exception(f"Error processing trades for {symbol}: {e}")
                continue

        # Process carry-forward positions (open positions from previous days not in today's trades,
        # and positions opened previously but closed today via exit-only trades)
        has_carryforward_positions = False

        if current_positions:
            ist = pytz.timezone("Asia/Kolkata")

            for pos_key, pos_data in current_positions.items():
                parts = pos_key.rsplit("_", 1)
                if len(parts) != 2:
                    logger.warning(f"Could not parse position key: {pos_key}")
                    continue

                symbol, exchange = parts
                pnl_col = f"{symbol}_pnl"
                qty = pos_data["quantity"]
                avg_price = pos_data["average_price"]
                position_pnl_value = pos_data["pnl"]

                # Case 1: Open carry-forward position (no trades today for this symbol)
                if qty != 0 and pos_key not in symbol_trades:
                    try:
                        history_rate_limiter.wait()
                        success, hist_response, _ = get_history(
                            symbol=symbol,
                            exchange=exchange,
                            interval="1m",
                            start_date=today_str,
                            end_date=today_str,
                            api_key=api_key,
                        )

                        if success and "data" in hist_response:
                            df_hist = pd.DataFrame(hist_response["data"])
                            if not df_hist.empty:
                                df_hist = convert_timestamp_to_ist(df_hist, symbol)

                                if df_hist is not None:
                                    current_time = datetime.now(ist)
                                    market_open = df_hist.index[0].replace(
                                        hour=9, minute=15, second=0, microsecond=0
                                    )
                                    df_hist = df_hist[df_hist.index >= market_open]
                                    df_hist = df_hist[df_hist.index <= current_time]

                                    df_hist = df_hist[["close"]].copy()
                                    df_hist.rename(
                                        columns={"close": f"{symbol}_price"}, inplace=True
                                    )

                                    if qty > 0:
                                        df_hist[pnl_col] = (
                                            df_hist[f"{symbol}_price"] - avg_price
                                        ) * qty
                                    else:
                                        df_hist[pnl_col] = (
                                            avg_price - df_hist[f"{symbol}_price"]
                                        ) * abs(qty)

                                    if portfolio_pnl is None:
                                        portfolio_pnl = df_hist[[pnl_col]].copy()
                                    else:
                                        portfolio_pnl = portfolio_pnl.join(
                                            df_hist[[pnl_col]], how="outer"
                                        )

                                    has_carryforward_positions = True
                                    logger.info(
                                        f"Added PnL for carry-forward position {symbol}: "
                                        f"{len(df_hist)} data points"
                                    )
                        else:
                            logger.warning(
                                f"Could not get historical data for carry-forward position {symbol}"
                            )

                    except Exception as e:
                        logger.exception(
                            f"Error processing carry-forward position {symbol}: {e}"
                        )
                        continue

                # Case 2: Closed carry-forward position (exit-only trades today, no entry trade)
                elif qty == 0 and position_pnl_value != 0 and pos_key in symbol_trades:
                    trades_for_symbol = symbol_trades[pos_key]
                    if not trades_for_symbol:
                        continue

                    # Check if only exit trades exist (not a same-day round-trip)
                    actions = [t.get("action") for t in trades_for_symbol]
                    if "BUY" in actions and "SELL" in actions:
                        continue  # Same-day round-trip, trade processing handled it

                    if all(a == "SELL" for a in actions):
                        was_long = True
                    elif all(a == "BUY" for a in actions):
                        was_long = False
                    else:
                        continue

                    total_exit_qty = sum(
                        float(t.get("quantity", 0)) for t in trades_for_symbol
                    )
                    if total_exit_qty == 0:
                        continue

                    total_value = sum(
                        float(t.get("average_price", 0)) * float(t.get("quantity", 0))
                        for t in trades_for_symbol
                    )
                    exit_price = total_value / total_exit_qty

                    # Reconstruct entry price from realized PnL
                    if was_long:
                        entry_price = exit_price - position_pnl_value / total_exit_qty
                    else:
                        entry_price = exit_price + position_pnl_value / total_exit_qty

                    close_time = trades_for_symbol[-1].get("parsed_time")

                    try:
                        history_rate_limiter.wait()
                        success, hist_response, _ = get_history(
                            symbol=symbol,
                            exchange=exchange,
                            interval="1m",
                            start_date=today_str,
                            end_date=today_str,
                            api_key=api_key,
                        )

                        if success and "data" in hist_response:
                            df_hist = pd.DataFrame(hist_response["data"])
                            if not df_hist.empty:
                                df_hist = convert_timestamp_to_ist(df_hist, symbol)

                                if df_hist is not None:
                                    current_time = datetime.now(ist)
                                    market_open = df_hist.index[0].replace(
                                        hour=9, minute=15, second=0, microsecond=0
                                    )
                                    df_hist = df_hist[df_hist.index >= market_open]
                                    df_hist = df_hist[df_hist.index <= current_time]

                                    df_hist = df_hist[["close"]].copy()
                                    df_hist.rename(
                                        columns={"close": f"{symbol}_price"},
                                        inplace=True,
                                    )

                                    # MTM before close, realized PnL after close
                                    df_hist[pnl_col] = 0.0

                                    if close_time:
                                        before_close = df_hist.index <= close_time
                                        after_close = df_hist.index > close_time
                                    else:
                                        before_close = pd.Series(
                                            True, index=df_hist.index
                                        )
                                        after_close = pd.Series(
                                            False, index=df_hist.index
                                        )

                                    if was_long:
                                        df_hist.loc[before_close, pnl_col] = (
                                            df_hist.loc[
                                                before_close, f"{symbol}_price"
                                            ]
                                            - entry_price
                                        ) * total_exit_qty
                                    else:
                                        df_hist.loc[before_close, pnl_col] = (
                                            entry_price
                                            - df_hist.loc[
                                                before_close, f"{symbol}_price"
                                            ]
                                        ) * total_exit_qty

                                    if after_close.any():
                                        df_hist.loc[after_close, pnl_col] = (
                                            position_pnl_value
                                        )

                                    # Remove incorrect trade-based column if present
                                    if (
                                        portfolio_pnl is not None
                                        and pnl_col in portfolio_pnl.columns
                                    ):
                                        portfolio_pnl.drop(
                                            columns=[pnl_col], inplace=True
                                        )
                                        if len(portfolio_pnl.columns) == 0:
                                            portfolio_pnl = None

                                    if portfolio_pnl is None:
                                        portfolio_pnl = df_hist[[pnl_col]].copy()
                                    else:
                                        portfolio_pnl = portfolio_pnl.join(
                                            df_hist[[pnl_col]], how="outer"
                                        )

                                    has_carryforward_positions = True
                                    logger.info(
                                        f"Added PnL for carry-forward closed position {symbol}: "
                                        f"{len(df_hist)} data points, "
                                        f"entry={entry_price:.2f}, exit={exit_price:.2f}, "
                                        f"realized PnL={position_pnl_value}"
                                    )
                        else:
                            logger.warning(
                                f"Could not get historical data for carry-forward "
                                f"closed position {symbol}"
                            )

                    except Exception as e:
                        logger.exception(
                            f"Error processing carry-forward closed position {symbol}: {e}"
                        )
                        continue

        # If we have no portfolio data but have positions, fetch historical data for positions
        if portfolio_pnl is None and current_positions:
            logger.info(
                "No trades found, but positions exist. Fetching historical data for positions."
            )

            # Process each position and get its historical data
            for pos_key, pos_data in current_positions.items():
                # Extract symbol and exchange from the key
                parts = pos_key.rsplit("_", 1)
                if len(parts) == 2:
                    symbol, exchange = parts
                else:
                    logger.warning(f"Could not parse position key: {pos_key}")
                    continue

                qty = pos_data["quantity"]
                avg_price = pos_data["average_price"]

                if qty == 0:
                    continue

                try:
                    # Apply rate limiting before API call (2 calls/sec to stay under broker's 3/sec limit)
                    history_rate_limiter.wait()
                    logger.debug(f"Fetching historical data for position {symbol} on {exchange}")

                    # Get historical data for this position
                    success, hist_response, _ = get_history(
                        symbol=symbol,
                        exchange=exchange,
                        interval="1m",
                        start_date=today_str,
                        end_date=today_str,
                        api_key=api_key,
                    )

                    if success and "data" in hist_response:
                        df_hist = pd.DataFrame(hist_response["data"])
                        if not df_hist.empty:
                            # Convert timestamp to IST with robust handling
                            df_hist = convert_timestamp_to_ist(df_hist, symbol)

                            if df_hist is not None:
                                # Filter to show data from first trade time onwards
                                ist = pytz.timezone("Asia/Kolkata")
                                current_time = datetime.now(ist)

                                # For positions without trades, we still need to determine when to start
                                # Use market open time as default
                                today_915am = df_hist.index[0].replace(
                                    hour=9, minute=15, second=0, microsecond=0
                                )
                                df_hist = df_hist[df_hist.index >= today_915am]
                                df_hist = df_hist[df_hist.index <= current_time]
                            else:
                                logger.warning(
                                    f"Timestamp conversion failed for position {symbol}, skipping"
                                )
                                continue

                            df_hist = df_hist[["close"]].copy()
                            df_hist.rename(columns={"close": f"{symbol}_price"}, inplace=True)

                            # Calculate MTM PnL for this position
                            # For positions, we use the average price from the position data
                            if qty > 0:  # Long position
                                df_hist[f"{symbol}_pnl"] = (
                                    df_hist[f"{symbol}_price"] - avg_price
                                ) * qty
                            else:  # Short position
                                df_hist[f"{symbol}_pnl"] = (
                                    avg_price - df_hist[f"{symbol}_price"]
                                ) * abs(qty)

                            # Combine into portfolio
                            if portfolio_pnl is None:
                                portfolio_pnl = df_hist[[f"{symbol}_pnl"]].copy()
                            else:
                                portfolio_pnl = portfolio_pnl.join(
                                    df_hist[[f"{symbol}_pnl"]], how="outer"
                                )

                            logger.info(
                                f"Added PnL for position {symbol}: {len(df_hist)} data points"
                            )
                    else:
                        logger.warning(f"Could not get historical data for position {symbol}")

                except Exception as e:
                    logger.exception(f"Error processing position for {symbol}: {e}")
                    continue

            # If we still couldn't get any historical data, create a simple flat line
            if portfolio_pnl is None:
                ist = pytz.timezone("Asia/Kolkata")
                current_time = datetime.now(ist)
                start_time = current_time.replace(hour=9, minute=0, second=0, microsecond=0)
                end_time = current_time

                if end_time <= start_time:
                    end_time = start_time + timedelta(minutes=1)

                time_range = pd.date_range(start=start_time, end=end_time, freq="1min", tz=ist)
                portfolio_pnl = pd.DataFrame(index=time_range)

                # Use current position P&L as constant value
                total_pnl = sum(pos["pnl"] for pos in current_positions.values())
                portfolio_pnl["Total_PnL"] = total_pnl
            else:
                # Historical data was fetched for positions - calculate Total_PnL
                portfolio_pnl = portfolio_pnl.ffill().fillna(0)
                portfolio_pnl["Total_PnL"] = portfolio_pnl.sum(axis=1)
        elif portfolio_pnl is not None:
            # Add zero PnL data from market open to first trade if needed
            # Skip when carry-forward positions exist (they already have data from market open)
            if first_trade_time and trades and not has_carryforward_positions:
                ist = pytz.timezone("Asia/Kolkata")
                market_open = first_trade_time.replace(hour=9, minute=15, second=0, microsecond=0)

                # Only add pre-trade data if first trade is after market open
                if first_trade_time > market_open:
                    # Create a zero PnL series from market open to first trade
                    pre_trade_index = pd.date_range(
                        start=market_open, end=first_trade_time, freq="1min", tz=ist
                    )[:-1]  # Exclude the first trade time itself

                    if len(pre_trade_index) > 0:
                        # Create zero PnL dataframe for pre-trade period
                        pre_trade_df = pd.DataFrame(index=pre_trade_index)
                        for col in portfolio_pnl.columns:
                            pre_trade_df[col] = 0

                        # Combine pre-trade zeros with actual PnL data
                        portfolio_pnl = pd.concat([pre_trade_df, portfolio_pnl]).sort_index()
                        logger.info(
                            f"Added {len(pre_trade_index)} minutes of zero PnL before first trade"
                        )

            # Calculate total MTM and drawdown
            # Use ffill() instead of fillna(method='ffill') for pandas 2.x compatibility
            portfolio_pnl = portfolio_pnl.ffill().fillna(0)
            portfolio_pnl["Total_PnL"] = portfolio_pnl.sum(axis=1)
        else:
            # No data at all
            return jsonify(
                {
                    "status": "success",
                    "data": {
                        "current_mtm": 0,
                        "max_mtm": 0,
                        "max_mtm_time": None,
                        "min_mtm": 0,
                        "min_mtm_time": None,
                        "max_drawdown": 0,
                        "pnl_series": [],
                        "drawdown_series": [],
                    },
                }
            ), 200

        # Calculate drawdown
        portfolio_pnl["Peak"] = portfolio_pnl["Total_PnL"].cummax()
        portfolio_pnl["Drawdown"] = portfolio_pnl["Total_PnL"] - portfolio_pnl["Peak"]

        # Calculate metrics
        latest_mtm = portfolio_pnl["Total_PnL"].iloc[-1] if not portfolio_pnl.empty else 0
        max_mtm = portfolio_pnl["Total_PnL"].max() if not portfolio_pnl.empty else 0
        min_mtm = portfolio_pnl["Total_PnL"].min() if not portfolio_pnl.empty else 0
        max_drawdown = portfolio_pnl["Drawdown"].min() if not portfolio_pnl.empty else 0

        try:
            max_mtm_time = (
                portfolio_pnl["Total_PnL"].idxmax().strftime("%H:%M")
                if not portfolio_pnl.empty
                else None
            )
            min_mtm_time = (
                portfolio_pnl["Total_PnL"].idxmin().strftime("%H:%M")
                if not portfolio_pnl.empty
                else None
            )
        except Exception:
            max_mtm_time = None
            min_mtm_time = None

        # Convert to series format for frontend
        pnl_series = []
        drawdown_series = []

        if not portfolio_pnl.empty:
            for idx, row in portfolio_pnl.iterrows():
                try:
                    # Convert to timestamp - handle timezone-aware datetime
                    if hasattr(idx, "tz") and idx.tz is not None:
                        # Already timezone-aware, convert to UTC then to timestamp
                        timestamp_ms = int(idx.tz_convert("UTC").timestamp() * 1000)
                    else:
                        # Naive datetime, assume it's already in local time
                        timestamp_ms = int(idx.timestamp() * 1000)
                    pnl_value = row.get("Total_PnL", 0)
                    drawdown_value = row.get("Drawdown", 0)

                    # Handle NaN values
                    if pd.isna(pnl_value):
                        pnl_value = 0
                    if pd.isna(drawdown_value):
                        drawdown_value = 0

                    pnl_series.append({"time": timestamp_ms, "value": round(float(pnl_value), 2)})
                    drawdown_series.append(
                        {"time": timestamp_ms, "value": round(float(drawdown_value), 2)}
                    )
                except Exception as e:
                    logger.warning(f"Error processing row {idx}: {e}")
                    continue

        logger.info(
            f"Final metrics - Current: {latest_mtm}, Max: {max_mtm}, Min: {min_mtm}, Drawdown: {max_drawdown}"
        )
        logger.info(f"PnL series length: {len(pnl_series)}")

        return jsonify(
            {
                "status": "success",
                "data": {
                    "current_mtm": round(latest_mtm, 2),
                    "max_mtm": round(max_mtm, 2),
                    "max_mtm_time": max_mtm_time,
                    "min_mtm": round(min_mtm, 2),
                    "min_mtm_time": min_mtm_time,
                    "max_drawdown": round(max_drawdown, 2),
                    "pnl_series": pnl_series,
                    "drawdown_series": drawdown_series,
                },
            }
        ), 200

    except Exception as e:
        logger.exception(f"Error calculating intraday PnL: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500
