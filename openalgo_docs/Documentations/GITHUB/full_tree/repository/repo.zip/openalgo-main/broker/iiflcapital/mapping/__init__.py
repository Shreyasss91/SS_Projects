"""IIFL Capital mapping modules."""
