# DefinedGe Securities database modules
