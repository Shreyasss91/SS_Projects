"""IIFL Capital streaming modules."""
