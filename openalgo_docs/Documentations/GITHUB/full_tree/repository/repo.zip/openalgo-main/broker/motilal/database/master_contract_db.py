# database/master_contract_db.py

import io
import os
import re
from datetime import datetime

import pandas as pd
from sqlalchemy import Column, Float, Index, Integer, Sequence, String, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import scoped_session, sessionmaker

from extensions import socketio  # Import SocketIO
from utils.httpx_client import get_httpx_client
from utils.logging import get_logger

logger = get_logger(__name__)


DATABASE_URL = os.getenv("DATABASE_URL")  # Replace with your database path

engine = create_engine(DATABASE_URL)
db_session = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=engine))
Base = declarative_base()
Base.query = db_session.query_property()


class SymToken(Base):
    __tablename__ = "symtoken"
    id = Column(Integer, Sequence("symtoken_id_seq"), primary_key=True)
    symbol = Column(String, nullable=False, index=True)  # Single column index
    brsymbol = Column(String, nullable=False, index=True)  # Single column index
    name = Column(String)
    exchange = Column(String, index=True)  # Include this column in a composite index
    brexchange = Column(String, index=True)
    token = Column(String, index=True)  # Indexed for performance
    expiry = Column(String)
    strike = Column(Float)
    lotsize = Column(Integer)
    instrumenttype = Column(String)
    tick_size = Column(Float)

    # Define a composite index on symbol and exchange columns
    __table_args__ = (Index("idx_symbol_exchange", "symbol", "exchange"),)


def init_db():
    logger.info("Initializing Master Contract DB")
    Base.metadata.create_all(bind=engine)


def delete_symtoken_table():
    logger.info("Deleting Symtoken Table")
    SymToken.query.delete()
    db_session.commit()


def copy_from_dataframe(df):
    logger.info("Performing Bulk Insert")
    # Convert DataFrame to a list of dictionaries
    data_dict = df.to_dict(orient="records")

    # Retrieve existing tokens to filter them out from the insert
    existing_tokens = {result.token for result in db_session.query(SymToken.token).all()}

    # Filter out data_dict entries with tokens that already exist
    filtered_data_dict = [row for row in data_dict if row["token"] not in existing_tokens]

    # Insert in bulk the filtered records
    try:
        if filtered_data_dict:  # Proceed only if there's anything to insert
            db_session.bulk_insert_mappings(SymToken, filtered_data_dict)
            db_session.commit()
            logger.info(
                f"Bulk insert completed successfully with {len(filtered_data_dict)} new records."
            )
        else:
            logger.info("No new records to insert.")
    except Exception as e:
        logger.error(f"Error during bulk insert: {e}")
        db_session.rollback()


def download_csv_motilal_data(exchange_name):
    """
    Downloads the CSV file from Motilal Oswal for a specific exchange.

    Args:
        exchange_name (str): Exchange name (e.g., 'NSE', 'BSE', 'NSEFO', 'NSECD', 'MCX', etc.)

    Returns:
        pd.DataFrame: DataFrame containing the downloaded instrument data
    """
    try:
        # Get the shared httpx client
        client = get_httpx_client()

        # Motilal Oswal CSV download URL
        url = f"https://openapi.motilaloswal.com/getscripmastercsv?name={exchange_name}"

        logger.info(f"Downloading Motilal scrip master for {exchange_name} from {url}")

        # Make the GET request using the shared client
        response = client.get(url, timeout=30)
        response.raise_for_status()  # Raises an exception for 4XX/5XX responses

        # Process the response directly as CSV
        csv_string = response.text
        df = pd.read_csv(io.StringIO(csv_string))

        logger.info(f"Downloaded {len(df)} records for {exchange_name}")
        return df

    except Exception as e:
        error_message = str(e)
        logger.error(f"Error downloading Motilal instruments for {exchange_name}: {error_message}")
        raise


# --- Index symbol normalization (Motilal-specific) -----------------------
#
# Motilal ships index names in its own house-style ("Nifty 50", "BSE CAPGOOD",
# "SNXT50", ...) while OpenAlgo needs canonical symbols per symbol_Openalgo.md.
# The mapping is kept local to this broker loader so other brokers — which
# already feed clean strings — aren't affected.

# Broker-house-style NSE index name -> OpenAlgo canonical symbol. Keys are
# upper-cased and whitespace-stripped before lookup.
_NSE_INDEX_ALIASES: dict[str, str] = {
    "NIFTY50": "NIFTY",
    "NIFTYNEXT50": "NIFTYNXT50",
    "NIFTYFINSERVICE": "FINNIFTY",
    "NIFTYFINSERV": "FINNIFTY",
    "NIFTYBANK": "BANKNIFTY",
    "NIFTYMIDSELECT": "MIDCPNIFTY",
    "NIFTYMIDCAPSELECT": "MIDCPNIFTY",
    "INDIAVIX": "INDIAVIX",
}

# Broker-house-style BSE index name -> OpenAlgo canonical symbol. Keys are
# matched against the raw broker string after upper-casing + collapsing runs
# of whitespace to a single space (so "BSE  CAPGOOD" still hits "BSE CAPGOOD").
_BSE_INDEX_ALIASES_RAW: dict[str, str] = {
    "BSE SENSEX": "SENSEX",
    "BSE BANKEX": "BANKEX",
    "SNSX50": "SENSEX50",
    "BSE 100": "BSE100",
    "BSE 150 MIDCAP": "BSE150MIDCAPINDEX",
    "BSE 200": "BSE200",
    "BSE 250 LARGEMIDCAP": "BSE250LARGEMIDCAPINDEX",
    "BSE 400 MIDSMALLCAP": "BSE400MIDSMALLCAPINDEX",
    "BSE 500": "BSE500",
    "BSE AUTO": "BSEAUTO",
    "BSE CAPGOOD": "BSECAPITALGOODS",
    "BSE CARBON": "BSECARBONEX",
    "BSE CONSDUR": "BSECONSUMERDURABLES",
    "BSE CPSE": "BSECPSE",
    "BSE DOLLEX 100": "BSEDOLLEX100",
    "BSE DOLLEX 200": "BSEDOLLEX200",
    "BSE DOLLEX 30": "BSEDOLLEX30",
    "BSE ENERGY": "BSEENERGY",
    "BSE FMCG": "BSEFASTMOVINGCONSUMERGOODS",
    "BSE FINANCIAL SERVICES": "BSEFINANCIALSERVICES",
    "BSE GREENEX": "BSEGREENEX",
    "BSE HEALTHCARE": "BSEHEALTHCARE",
    "BSE INFRA": "BSEINDIAINFRASTRUCTUREINDEX",
    "BSE INDUSTRIALS": "BSEINDUSTRIALS",
    "BSE IT": "BSEINFORMATIONTECHNOLOGY",
    "BSE IPO": "BSEIPO",
    "BSE LARGECAP": "BSELARGECAP",
    "BSE METAL": "BSEMETAL",
    "BSE MIDCAP": "BSEMIDCAP",
    "BSE MIDCAP SELECT": "BSEMIDCAPSELECTINDEX",
    "BSE OIL&GAS": "BSEOIL&GAS",
    "BSE POWER": "BSEPOWER",
    "BSE PSU": "BSEPSU",
    "BSE REALTY": "BSEREALTY",
    "SNXT50": "BSESENSEXNEXT50",
    "BSE SMALLCAP": "BSESMALLCAP",
    "BSE SMALLCAP SELECT": "BSESMALLCAPSELECTINDEX",
    "BSE SME IPO": "BSESMEIPO",
    "BSE TECK": "BSETECK",
    "BSE TELECOM": "BSETELECOM",
}

_WHITESPACE_RE = re.compile(r"\s+")


def _collapse_ws(s: str) -> str:
    """Upper-case + collapse runs of whitespace to a single space + strip."""
    return _WHITESPACE_RE.sub(" ", s.upper()).strip()


_BSE_INDEX_ALIASES = {_collapse_ws(k): v for k, v in _BSE_INDEX_ALIASES_RAW.items()}


def _normalize_nse_index_symbol(broker_symbol):
    """NSE: upper + strip whitespace, then alias lookup; unlisted fall through."""
    if not broker_symbol:
        return broker_symbol
    cleaned = _WHITESPACE_RE.sub("", str(broker_symbol).upper())
    return _NSE_INDEX_ALIASES.get(cleaned, cleaned)


def _normalize_bse_index_symbol(broker_symbol):
    """
    BSE: alias lookup first (keys contain spaces / abbreviations that can't
    be auto-derived, e.g. "BSE CAPGOOD" -> "BSECAPITALGOODS"), then fall back
    to upper + strip whitespace so unlisted indices still come out canonical
    ("BSE 1000" -> "BSE1000").
    """
    if not broker_symbol:
        return broker_symbol
    raw = str(broker_symbol)
    aliased = _BSE_INDEX_ALIASES.get(_collapse_ws(raw))
    if aliased is not None:
        return aliased
    return _WHITESPACE_RE.sub("", raw.upper())


def standardize_index_symbols(df):
    """
    Standardize NSE_INDEX and BSE_INDEX symbol names to OpenAlgo canonical form
    using Motilal-specific alias maps. Symbols not in the maps pass through
    after basic cleanup (upper-case + whitespace removed). NaN rows are
    preserved — the old `.str` pipeline was NaN-safe and `.apply` is not.
    """
    nse_idx_mask = df["exchange"] == "NSE_INDEX"
    if nse_idx_mask.any():
        df.loc[nse_idx_mask, "symbol"] = df.loc[nse_idx_mask, "symbol"].apply(
            lambda s: _normalize_nse_index_symbol(s) if pd.notna(s) else s
        )

    bse_idx_mask = df["exchange"] == "BSE_INDEX"
    if bse_idx_mask.any():
        df.loc[bse_idx_mask, "symbol"] = df.loc[bse_idx_mask, "symbol"].apply(
            lambda s: _normalize_bse_index_symbol(s) if pd.notna(s) else s
        )

    return df


def extract_expiry_from_scripname(scripname):
    """
    Extract expiry date from scripname and convert to DD-MMM-YY format.
    Args:
        scripname: Script name like "TGBL 30-OCT-2025 CE 1180"
    Returns:
        str: Formatted date string (DD-MMM-YY) or empty string
    """
    try:
        if pd.isna(scripname) or scripname == "":
            return ""

        # Split the scripname by spaces
        parts = str(scripname).split()

        # Look for date pattern DD-MMM-YYYY
        import re

        for part in parts:
            # Match pattern like 30-OCT-2025 or 30-Oct-2025
            if re.match(r"\d{1,2}-[A-Za-z]{3}-\d{4}", part):
                # Parse and reformat to DD-MMM-YY
                date_obj = datetime.strptime(part, "%d-%b-%Y")
                return date_obj.strftime("%d-%b-%y").upper()

        return ""
    except (ValueError, AttributeError):
        return ""


def download_csv_index_data(exchange_name):
    """
    Downloads the index CSV file from Motilal Oswal for NSE/BSE indices.

    Args:
        exchange_name (str): Exchange name ('NSE' or 'BSE')

    Returns:
        pd.DataFrame: DataFrame containing the downloaded index data
    """
    try:
        # Get the shared httpx client
        client = get_httpx_client()

        # Motilal Oswal Index CSV download URL
        url = f"https://openapi.motilaloswal.com/getindexdatacsv?name={exchange_name}"

        logger.info(f"Downloading Motilal index data for {exchange_name} from {url}")

        # Make the GET request using the shared client
        response = client.get(url, timeout=30)
        response.raise_for_status()

        # Process the response directly as CSV
        csv_string = response.text
        df = pd.read_csv(io.StringIO(csv_string))

        logger.info(f"Downloaded {len(df)} index records for {exchange_name}")
        return df

    except Exception as e:
        error_message = str(e)
        logger.error(f"Error downloading Motilal index data for {exchange_name}: {error_message}")
        raise


def process_motilal_index_csv(df, exchange_name):
    """
    Processes the Motilal Index CSV file to fit the OpenAlgo database schema.

    Args:
        df (pd.DataFrame): Raw DataFrame from Motilal Index API
        exchange_name (str): Exchange name ('NSE' or 'BSE')

    Returns:
        pd.DataFrame: Processed DataFrame ready for database insertion
    """
    logger.info(f"Processing Motilal Index CSV Data for {exchange_name}")

    # Rename columns based on Motilal Index API format
    df = df.rename(
        columns={"indexcode": "token", "indexname": "symbol", "exchangename": "brexchange"}
    )

    # Set the name same as symbol for indices
    df["name"] = df["symbol"]
    df["brsymbol"] = df["symbol"]

    # Map exchange to OpenAlgo format with _INDEX suffix
    if exchange_name == "NSE":
        df["exchange"] = "NSE_INDEX"
    elif exchange_name == "BSE":
        df["exchange"] = "BSE_INDEX"
    else:
        df["exchange"] = exchange_name + "_INDEX"

    # Set instrumenttype for indices
    df["instrumenttype"] = "INDEX"

    # Set default values for fields not applicable to indices
    df["expiry"] = ""
    df["strike"] = 0.0
    df["lotsize"] = 1
    df["tick_size"] = 0.05

    # Standardize index symbols to OpenAlgo format
    df = standardize_index_symbols(df)

    # Select only the columns needed for the database
    required_columns = [
        "token",
        "symbol",
        "brsymbol",
        "name",
        "exchange",
        "brexchange",
        "expiry",
        "strike",
        "lotsize",
        "instrumenttype",
        "tick_size",
    ]

    df = df[required_columns]

    # Fill NaN values
    df["symbol"] = df["symbol"].fillna("")
    df["brsymbol"] = df["brsymbol"].fillna("")
    df["name"] = df["name"].fillna("")

    logger.info(f"Processed {len(df)} index records for {exchange_name}")
    return df


def process_motilal_csv(df, exchange_name):
    """
    Processes the Motilal CSV file to fit the OpenAlgo database schema.

    Args:
        df (pd.DataFrame): Raw DataFrame from Motilal API
        exchange_name (str): Exchange name for processing

    Returns:
        pd.DataFrame: Processed DataFrame ready for database insertion
    """
    logger.info(f"Processing Motilal CSV Data for {exchange_name}")

    # Rename columns based on Motilal API format to OpenAlgo schema
    df = df.rename(
        columns={
            "scripcode": "token",
            "scripname": "symbol",
            "scripshortname": "name",
            "marketlot": "lotsize",
            "instrumentname": "instrumenttype",
            "expirydate": "expiry",
            "strikeprice": "strike",
            "ticksize": "tick_size",
            "exchangename": "brexchange",
        }
    )

    # Add broker symbol and exchange (keep original)
    df["brsymbol"] = df["symbol"]

    # Map Motilal exchange names to OpenAlgo exchange names
    exchange_map = {
        "NSE": "NSE",
        "BSE": "BSE",
        "NSEFO": "NFO",
        "NSECD": "CDS",
        "MCX": "MCX",
        "BSEFO": "BFO",
        "BSECD": "BCD",
        "NCDEX": "NCDEX",
        "NSECO": "CDS",
        "BSECO": "BCD",
    }

    df["exchange"] = df["brexchange"].map(exchange_map).fillna(df["brexchange"])

    # Extract expiry date from scripname (brsymbol) instead of timestamp
    df["expiry"] = df["brsymbol"].apply(extract_expiry_from_scripname)

    # Convert strike price (Motilal sends it in correct format, no conversion needed)
    df["strike"] = pd.to_numeric(df["strike"], errors="coerce").fillna(0)

    # Convert lotsize to int
    df["lotsize"] = pd.to_numeric(df["lotsize"], errors="coerce").fillna(1).astype(int)

    # Motilal CSV already provides tick_size in rupees (e.g. 0.05), no conversion needed.
    df["tick_size"] = pd.to_numeric(df["tick_size"], errors="coerce").fillna(0.05)

    # Convert token to string
    df["token"] = df["token"].astype(str)

    # Process option type column
    if "optiontype" in df.columns:
        df["optiontype"] = df["optiontype"].fillna("XX")
    else:
        df["optiontype"] = "XX"

    # Update instrumenttype to match Angel format (FUT, CE, PE, etc.)
    # For Futures - set to 'FUT' (only when optiontype is XX, i.e., not an option)
    df.loc[
        (df["instrumenttype"].str.contains("FUT", na=False)) & (df["optiontype"] == "XX"),
        "instrumenttype",
    ] = "FUT"

    # For Options - set to 'CE' or 'PE' based on optiontype column directly
    df.loc[df["optiontype"] == "CE", "instrumenttype"] = "CE"
    df.loc[df["optiontype"] == "PE", "instrumenttype"] = "PE"

    # Format symbols according to OpenAlgo standards

    # For Index instruments, update exchange
    df.loc[
        (df["instrumenttype"].str.contains("IDX", na=False)) & (df["exchange"] == "NSE"), "exchange"
    ] = "NSE_INDEX"
    df.loc[
        (df["instrumenttype"].str.contains("IDX", na=False)) & (df["exchange"] == "BSE"), "exchange"
    ] = "BSE_INDEX"
    df.loc[
        (df["instrumenttype"].str.contains("IDX", na=False)) & (df["exchange"] == "MCX"), "exchange"
    ] = "MCX_INDEX"

    # Helper function to format strike price
    def format_strike(strike):
        try:
            strike_float = float(strike)
            # If strike has decimal part, keep it; otherwise show as integer
            if strike_float % 1 == 0:
                return str(int(strike_float))
            else:
                # Remove trailing zeros after decimal point
                return str(strike_float).rstrip("0").rstrip(".")
        except Exception:
            return str(strike)

    # Format Futures symbols: NAME + EXPIRY(no dashes) + FUT
    # For MCX and CDS, use brsymbol if expiry exists, otherwise use name
    df.loc[
        (df["instrumenttype"] == "FUT")
        & (df["exchange"].isin(["MCX", "CDS"]))
        & (df["expiry"] != ""),
        "symbol",
    ] = df["name"] + df["expiry"].str.replace("-", "", regex=False) + "FUT"
    # For other exchanges with FUT
    df.loc[(df["instrumenttype"] == "FUT") & (~df["exchange"].isin(["MCX", "CDS"])), "symbol"] = (
        df["name"] + df["expiry"].str.replace("-", "", regex=False) + "FUT"
    )

    # Format Options symbols: NAME + EXPIRY(no dashes) + STRIKE + CE/PE
    # For MCX and CDS options
    df.loc[
        (df["instrumenttype"] == "CE")
        & (df["exchange"].isin(["MCX", "CDS"]))
        & (df["expiry"] != ""),
        "symbol",
    ] = (
        df["name"]
        + df["expiry"].str.replace("-", "", regex=False)
        + df["strike"].apply(format_strike)
        + "CE"
    )
    df.loc[
        (df["instrumenttype"] == "PE")
        & (df["exchange"].isin(["MCX", "CDS"]))
        & (df["expiry"] != ""),
        "symbol",
    ] = (
        df["name"]
        + df["expiry"].str.replace("-", "", regex=False)
        + df["strike"].apply(format_strike)
        + "PE"
    )
    # For other exchanges with options
    df.loc[(df["instrumenttype"] == "CE") & (~df["exchange"].isin(["MCX", "CDS"])), "symbol"] = (
        df["name"]
        + df["expiry"].str.replace("-", "", regex=False)
        + df["strike"].apply(format_strike)
        + "CE"
    )
    df.loc[(df["instrumenttype"] == "PE") & (~df["exchange"].isin(["MCX", "CDS"])), "symbol"] = (
        df["name"]
        + df["expiry"].str.replace("-", "", regex=False)
        + df["strike"].apply(format_strike)
        + "PE"
    )

    # Clean up equity symbols (remove EQ suffix if present)
    df.loc[df["instrumenttype"].str.contains("EQ|CASH", na=False, case=False), "symbol"] = (
        df["symbol"].str.replace(" EQ", "", regex=False).str.strip()
    )

    # Additional cleanup: Remove EQ suffix for NSE exchange
    df.loc[df["exchange"] == "NSE", "symbol"] = (
        df["symbol"].str.replace(" EQ", "", regex=False).str.strip()
    )

    # Standardize index symbols to OpenAlgo format
    df = standardize_index_symbols(df)

    # Select only the columns needed for the database
    required_columns = [
        "token",
        "symbol",
        "brsymbol",
        "name",
        "exchange",
        "brexchange",
        "expiry",
        "strike",
        "lotsize",
        "instrumenttype",
        "tick_size",
    ]

    df = df[required_columns]

    # Fill NaN values
    df["expiry"] = df["expiry"].fillna("")
    df["name"] = df["name"].fillna("")
    df["symbol"] = df["symbol"].fillna("")
    df["brsymbol"] = df["brsymbol"].fillna("")

    logger.info(f"Processed {len(df)} records for {exchange_name}")
    return df


def master_contract_download():
    """
    Downloads master contracts from Motilal Oswal for all supported exchanges including indices.
    """
    logger.info("Downloading Master Contract from Motilal Oswal")

    # List of exchanges to download scrip master data
    exchanges = ["NSE", "BSE", "NSEFO", "NSECD", "MCX", "BSEFO"]

    # List of exchanges to download index data
    index_exchanges = ["NSE", "BSE"]

    try:
        all_data = []

        # Download scrip master data for all exchanges
        for exchange in exchanges:
            try:
                logger.info(f"Downloading {exchange} scrip master data...")
                df = download_csv_motilal_data(exchange)
                processed_df = process_motilal_csv(df, exchange)
                all_data.append(processed_df)
                logger.info(f"Successfully processed {exchange} scrip master")
            except Exception as e:
                logger.error(f"Error processing {exchange}: {str(e)}")
                # Continue with other exchanges even if one fails
                continue

        # Download index data for NSE and BSE
        for exchange in index_exchanges:
            try:
                logger.info(f"Downloading {exchange} index data...")
                df = download_csv_index_data(exchange)
                processed_df = process_motilal_index_csv(df, exchange)
                all_data.append(processed_df)
                logger.info(f"Successfully processed {exchange} indices")
            except Exception as e:
                logger.error(f"Error processing {exchange} indices: {str(e)}")
                # Continue even if index download fails
                continue

        if not all_data:
            raise Exception("Failed to download data from any exchange")

        # Combine all exchange data (scrip master + indices)
        token_df = pd.concat(all_data, ignore_index=True)

        # Remove duplicates based on token
        token_df = token_df.drop_duplicates(subset="token", keep="first")

        logger.info(f"Total records to insert: {len(token_df)}")

        # Delete existing data and insert new data
        delete_symtoken_table()
        copy_from_dataframe(token_df)

        return socketio.emit(
            "master_contract_download",
            {
                "status": "success",
                "message": f"Successfully Downloaded {len(token_df)} instruments",
            },
        )

    except Exception as e:
        logger.error(f"Error in master_contract_download: {str(e)}")
        return socketio.emit("master_contract_download", {"status": "error", "message": str(e)})


def search_symbols(symbol, exchange):
    return SymToken.query.filter(
        SymToken.symbol.like(f"%{symbol}%"), SymToken.exchange == exchange
    ).all()
