import json
import os
import time
import urllib.parse
from datetime import datetime

import httpx
import pandas as pd

from database.token_db import get_br_symbol, get_oa_symbol
from utils.constants import FNO_EXCHANGES
from utils.httpx_client import get_httpx_client
from utils.logging import get_logger

logger = get_logger(__name__)


def get_api_response(endpoint, auth, method="GET", payload=""):
    """
    Make API requests to Fyers API using shared connection pooling.

    Args:
        endpoint: API endpoint (e.g., /api/v2/positions)
        auth: Authentication token
        method: HTTP method (GET, POST, etc.)
        payload: Request payload as a string or dict

    Returns:
        dict: Parsed JSON response from the API
    """
    try:
        # Get the shared httpx client with connection pooling
        client = get_httpx_client()

        AUTH_TOKEN = auth
        api_key = os.getenv("BROKER_API_KEY")

        url = f"https://api-t1.fyers.in{endpoint}"
        headers = {"Authorization": f"{api_key}:{AUTH_TOKEN}", "Content-Type": "application/json"}

        logger.debug(f"Making {method} request to Fyers API: {url}")

        # Make the request
        if method == "GET":
            response = client.get(url, headers=headers)
        elif method == "POST":
            response = client.post(
                url,
                headers=headers,
                json=payload if isinstance(payload, dict) else json.loads(payload),
            )
        else:
            response = client.request(
                method,
                url,
                headers=headers,
                json=payload if isinstance(payload, dict) else json.loads(payload),
            )

        # Add status attribute for compatibility
        response.status = response.status_code

        # Raise HTTPError for bad responses (4xx, 5xx)
        response.raise_for_status()

        # Parse and return the JSON response
        response_data = response.json()
        logger.debug(f"API response: {json.dumps(response_data, indent=2)}")
        return response_data

    except httpx.HTTPError as e:
        logger.error(f"HTTP error during API request: {str(e)}")
        return {"s": "error", "message": f"HTTP error: {str(e)}"}
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error: {str(e)}")
        return {"s": "error", "message": f"Invalid JSON response: {str(e)}"}
    except Exception as e:
        logger.exception("An unexpected error occurred during API request")
        return {"s": "error", "message": f"General error: {str(e)}"}


class BrokerData:
    # Fyers /data/depth limit: 1 symbol per call, 10 requests per second.
    _DEPTH_MIN_GAP_SECONDS = 0.1

    def __init__(self, auth_token):
        """Initialize Fyers data handler with authentication token"""
        self.auth_token = auth_token
        # Pacing clock for the per-symbol /data/depth endpoint (10 req/sec cap).
        self._last_depth_call_at = 0.0
        # Map common timeframe format to Fyers resolutions
        self.timeframe_map = {
            # Seconds - Use 'S' suffix for seconds timeframes
            "5s": "5S",
            "10s": "10S",
            "15s": "15S",
            "30s": "30S",
            "45s": "45S",
            # Minutes
            "1m": "1",
            "2m": "2",
            "3m": "3",
            "5m": "5",
            "10m": "10",
            "15m": "15",
            "20m": "20",
            "30m": "30",
            # Hours
            "1h": "60",
            "2h": "120",
            "4h": "240",
            # Daily
            "D": "1D",
        }

    def get_quotes(self, symbol: str, exchange: str) -> dict:
        """
        Get real-time quotes for given symbol using depth endpoint to include OI
        Args:
            symbol: Trading symbol
            exchange: Exchange (e.g., NSE, BSE)
        Returns:
            dict: Simplified quote data with required fields including OI
        """
        try:
            br_symbol = get_br_symbol(symbol, exchange)
            encoded_symbol = urllib.parse.quote(br_symbol)

            # Use depth endpoint to get quotes with OI data
            response = get_api_response(
                f"/data/depth?symbol={encoded_symbol}&ohlcv_flag=1", self.auth_token
            )
            logger.debug(f"Fyers quotes API response: {response}")

            if response.get("s") != "ok":
                error_msg = f"Error from Fyers API: {response.get('message', 'Unknown error')}"
                logger.error(error_msg)
                raise Exception(error_msg)

            depth_data = response.get("d", {}).get(br_symbol, {})
            if not depth_data:
                logger.warning(f"No depth data found for {br_symbol} in API response.")
                raise Exception(f"No quote data available for {exchange}:{symbol}")

            # Get bid/ask from depth data
            bids = depth_data.get("bids", [])
            asks = depth_data.get("ask", [])  # Fyers uses 'ask' (singular)

            bid_price = bids[0].get("price", 0) if bids else 0
            ask_price = asks[0].get("price", 0) if asks else 0

            return {
                "bid": bid_price,
                "ask": ask_price,
                "open": depth_data.get("o", 0),
                "high": depth_data.get("h", 0),
                "low": depth_data.get("l", 0),
                "ltp": depth_data.get("ltp", 0),
                "prev_close": depth_data.get("c", 0),
                "volume": depth_data.get("v", 0),
                "oi": int(depth_data.get("oi", 0)),
            }

        except Exception as e:
            logger.exception(f"Error fetching quotes for {exchange}:{symbol}")
            raise Exception(f"Error fetching quotes: {e}")

    def get_multiquotes(self, symbols: list) -> list:
        """
        Get real-time quotes for multiple symbols with automatic batching.

        OI policy: when the total request size is <= OI_THRESHOLD, OI is fetched
        per-symbol via /data/depth for derivative exchanges only. When the total
        exceeds OI_THRESHOLD, OI is set to 0 for every symbol — at 10 req/sec
        the depth calls dominate latency and would push the request well past
        a usable response time.

        Args:
            symbols: List of dicts with 'symbol' and 'exchange' keys
                     Example: [{'symbol': 'SBIN', 'exchange': 'NSE'}, ...]
        Returns:
            list: List of quote data for each symbol with format:
                  [{'symbol': 'SBIN', 'exchange': 'NSE', 'data': {...}}, ...]
        """
        try:
            BATCH_SIZE = 50  # Fyers /data/quotes limit per request
            RATE_LIMIT_DELAY = 0.1  # Delay in seconds between batch API calls
            OI_THRESHOLD = 100  # Skip OI entirely when total symbols exceed this

            fetch_oi = len(symbols) <= OI_THRESHOLD
            if not fetch_oi:
                logger.info(
                    f"Multiquote size {len(symbols)} > {OI_THRESHOLD}: skipping OI fetch (oi=0 for all symbols)"
                )

            # If symbols exceed batch size, process in batches
            if len(symbols) > BATCH_SIZE:
                logger.info(f"Processing {len(symbols)} symbols in batches of {BATCH_SIZE}")
                all_results = []

                # Split symbols into batches
                for i in range(0, len(symbols), BATCH_SIZE):
                    batch = symbols[i : i + BATCH_SIZE]
                    logger.debug(
                        f"Processing batch {i // BATCH_SIZE + 1}: symbols {i + 1} to {min(i + BATCH_SIZE, len(symbols))}"
                    )

                    # Process this batch
                    batch_results = self._process_quotes_batch(batch, fetch_oi=fetch_oi)
                    all_results.extend(batch_results)

                    # Rate limit delay between batches
                    if i + BATCH_SIZE < len(symbols):
                        time.sleep(RATE_LIMIT_DELAY)

                logger.info(
                    f"Successfully processed {len(all_results)} quotes in {(len(symbols) + BATCH_SIZE - 1) // BATCH_SIZE} batches"
                )
                return all_results
            else:
                # Single batch processing
                return self._process_quotes_batch(symbols, fetch_oi=fetch_oi)

        except Exception as e:
            logger.exception("Error fetching multiquotes")
            raise Exception(f"Error fetching multiquotes: {e}")

    def _fetch_oi_for_symbol(self, br_symbol: str) -> int:
        """
        Fetch OI for a single derivative symbol via /data/depth.

        Fyers' depth endpoint accepts one symbol at a time and is capped at
        10 req/sec; we pace calls with self._last_depth_call_at so the rate
        limit holds across batches within the same BrokerData instance.

        Returns 0 on any error so a single bad symbol doesn't fail the batch.
        """
        elapsed = time.monotonic() - self._last_depth_call_at
        if elapsed < self._DEPTH_MIN_GAP_SECONDS:
            time.sleep(self._DEPTH_MIN_GAP_SECONDS - elapsed)

        try:
            encoded = urllib.parse.quote(br_symbol)
            response = get_api_response(
                f"/data/depth?symbol={encoded}&ohlcv_flag=1", self.auth_token
            )
        finally:
            self._last_depth_call_at = time.monotonic()

        if response.get("s") != "ok":
            logger.debug(
                f"Depth fetch for OI failed for {br_symbol}: {response.get('message')}"
            )
            return 0

        depth_data = response.get("d", {}).get(br_symbol, {})
        return int(depth_data.get("oi", 0))

    def _process_quotes_batch(self, symbols: list, fetch_oi: bool = True) -> list:
        """
        Process a single batch of symbols using the bulk /data/quotes endpoint.

        OI handling: Fyers' /data/depth accepts only one symbol per call (bulk
        returns concatenated/incorrect arrays) at a 10 req/sec rate limit. When
        fetch_oi is True we fetch OI per-symbol for derivative exchanges only
        (FNO_EXCHANGES); equity/index symbols always get oi=0. When fetch_oi is
        False, all symbols get oi=0 — used by get_multiquotes when the total
        request size exceeds the OI threshold to keep the response fast.

        Args:
            symbols: List of dicts with 'symbol' and 'exchange' keys (max 50)
            fetch_oi: If False, skip /data/depth calls entirely and return oi=0
        Returns:
            list: List of quote data for the batch
        """
        # Convert symbols to broker format and build comma-separated list
        br_symbols = []
        symbol_map = {}  # Map br_symbol back to original symbol/exchange
        skipped_symbols = []  # Track symbols that couldn't be resolved

        for item in symbols:
            symbol = item["symbol"]
            exchange = item["exchange"]
            br_symbol = get_br_symbol(symbol, exchange)

            # Track symbols that couldn't be resolved
            if not br_symbol:
                logger.warning(
                    f"Skipping symbol {symbol} on {exchange}: could not resolve broker symbol"
                )
                skipped_symbols.append(
                    {
                        "symbol": symbol,
                        "exchange": exchange,
                        "error": "Could not resolve broker symbol",
                    }
                )
                continue

            br_symbols.append(br_symbol)
            symbol_map[br_symbol] = {"symbol": symbol, "exchange": exchange}

        # Return skipped symbols if no valid symbols
        if not br_symbols:
            logger.warning("No valid symbols to fetch quotes for")
            return skipped_symbols

        # Join all symbols with comma and URL encode
        symbols_param = ",".join(br_symbols)
        encoded_symbols = urllib.parse.quote(symbols_param)

        # Bulk /data/quotes for bid/ask/OHLC/LTP/volume (OI not provided in bulk)
        quotes_response = get_api_response(
            f"/data/quotes?symbols={encoded_symbols}", self.auth_token
        )
        logger.debug(f"Fyers quotes API response: {quotes_response}")

        # Parse quotes response - array format
        quotes_map = {}
        if quotes_response.get("s") == "ok":
            for quote_item in quotes_response.get("d", []):
                if quote_item.get("s") == "ok":
                    symbol_name = quote_item.get("n", "")
                    quotes_map[symbol_name] = quote_item.get("v", {})
        else:
            logger.warning(f"Quotes API error: {quotes_response.get('message', 'Unknown error')}")

        # Build results from quotes data; fetch OI per-symbol for derivatives only
        results = []
        for br_symbol in br_symbols:
            quote = quotes_map.get(br_symbol, {})

            if not quote:
                logger.warning(f"No data found for {br_symbol}")
                continue

            # Look up original symbol and exchange
            original = symbol_map.get(br_symbol, {"symbol": br_symbol, "exchange": "UNKNOWN"})

            oi_value = 0
            if fetch_oi and original["exchange"] in FNO_EXCHANGES:
                oi_value = self._fetch_oi_for_symbol(br_symbol)

            result_item = {
                "symbol": original["symbol"],
                "exchange": original["exchange"],
                "data": {
                    "bid": quote.get("bid", 0),
                    "ask": quote.get("ask", 0),
                    "open": quote.get("open_price", 0),
                    "high": quote.get("high_price", 0),
                    "low": quote.get("low_price", 0),
                    "ltp": quote.get("lp", 0),
                    "prev_close": quote.get("prev_close_price", 0),
                    "volume": quote.get("volume", 0),
                    "oi": oi_value,
                },
            }
            results.append(result_item)

        # Include skipped symbols in results
        return skipped_symbols + results

    def get_history(
        self, symbol: str, exchange: str, interval: str, start_date: str, end_date: str
    ) -> pd.DataFrame:
        """
        Get historical data for given symbol
        Args:
            symbol: Trading symbol
            exchange: Exchange (e.g., NSE, BSE)
            interval: Candle interval in common format:
                     Seconds: 5s, 10s, 15s, 30s, 45s
                     Minutes: 1m, 2m, 3m, 5m, 10m, 15m, 20m, 30m
                     Hours: 1h, 2h, 4h
                     Daily: D
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
        Returns:
            pd.DataFrame: Historical data with columns [timestamp (epoch), open, high, low, close, volume]
        """
        try:
            # Convert symbol to broker format
            br_symbol = get_br_symbol(symbol, exchange)
            logger.debug(f"Using broker symbol: {br_symbol}")

            # Check for unsupported timeframes first
            if interval in ["W", "M"]:
                raise Exception(
                    f"Timeframe '{interval}' is not supported by Fyers. Supported timeframes are:\n"
                    "Seconds: 5s, 10s, 15s, 30s, 45s\n"
                    "Minutes: 1m, 2m, 3m, 5m, 10m, 15m, 20m, 30m\n"
                    "Hours: 1h, 2h, 4h\n"
                    "Daily: D"
                )

            # Validate and map interval
            resolution = self.timeframe_map.get(interval)
            if not resolution:
                supported = {
                    "Seconds": ["5s", "10s", "15s", "30s", "45s"],
                    "Minutes": ["1m", "2m", "3m", "5m", "10m", "15m", "20m", "30m"],
                    "Hours": ["1h", "2h", "4h"],
                    "Daily": ["D"],
                }
                error_msg = "Unsupported timeframe. Supported timeframes:\n"
                for category, timeframes in supported.items():
                    error_msg += f"{category}: {', '.join(timeframes)}\n"
                raise Exception(error_msg)

            # Convert dates to datetime objects
            start_dt = pd.to_datetime(start_date)
            end_dt = pd.to_datetime(end_date)
            current_dt = pd.Timestamp.now()

            # Adjust end date if it's in the future
            if end_dt > current_dt:
                logger.warning(
                    f"Warning: End date {end_dt.date()} is in the future. Adjusting to current date {current_dt.date()}"
                )
                end_dt = current_dt

            # Validate date range
            if start_dt > end_dt:
                raise Exception(
                    f"Start date {start_dt.date()} cannot be after end date {end_dt.date()}"
                )

            # Special validation for seconds data (only available for last 30 trading days)
            if resolution.endswith("S"):
                max_days_ago = current_dt - pd.Timedelta(days=30)
                if start_dt < max_days_ago:
                    logger.warning(
                        f"Warning: Seconds data is only available for the last 30 trading days. "
                        f"Adjusting start date from {start_dt.date()} to {max_days_ago.date()}"
                    )
                    start_dt = max_days_ago

            # Initialize empty list to store DataFrames
            dfs = []

            # Determine chunk size based on resolution
            if resolution == "1D":
                chunk_days = 300  # For daily data
            elif resolution.endswith("S"):
                chunk_days = 25  # For seconds data - max 30 trading days, use 25 to be safe
            else:
                chunk_days = 60  # For minute/hour data

            # Process data in chunks
            current_start = start_dt
            retry_count = 0
            max_retries = 3

            while current_start <= end_dt:
                try:
                    # Calculate chunk end date
                    current_end = min(current_start + pd.Timedelta(days=chunk_days - 1), end_dt)

                    # Format dates for API call
                    chunk_start = current_start.strftime("%Y-%m-%d")
                    chunk_end = current_end.strftime("%Y-%m-%d")

                    logger.debug(
                        f"Fetching {resolution} data for {exchange}:{br_symbol} from {chunk_start} to {chunk_end}"
                    )

                    # URL encode the symbol to handle special characters
                    encoded_symbol = urllib.parse.quote(br_symbol)

                    # Determine if OI flag should be enabled based on exchange
                    # OI is only available for derivatives (NFO, BFO, MCX, CDS)
                    derivative_exchanges = ["NFO", "BFO", "MCX", "CDS"]
                    enable_oi = exchange in derivative_exchanges

                    # Construct endpoint with query parameters
                    endpoint = (
                        f"/data/history?"
                        f"symbol={encoded_symbol}&"
                        f"resolution={resolution}&"
                        f"date_format=1&"  # Keep epoch format
                        f"range_from={chunk_start}&"
                        f"range_to={chunk_end}&"
                        f"cont_flag=1"
                    )  # For continuous data

                    # Add OI flag only for derivatives
                    if enable_oi:
                        endpoint += "&oi_flag=1"

                    logger.debug(f"Making request to endpoint: {endpoint}")
                    response = get_api_response(endpoint, self.auth_token)

                    if response.get("s") != "ok":
                        error_msg = response.get("message", "Unknown error")
                        logger.error(f"Error for chunk {chunk_start} to {chunk_end}: {error_msg}")

                        if retry_count < max_retries:
                            retry_count += 1
                            logger.debug(f"Retrying... Attempt {retry_count} of {max_retries}")
                            time.sleep(2 * retry_count)  # Exponential backoff
                            continue

                        # If max retries reached, move to next chunk
                        retry_count = 0
                        current_start = current_end + pd.Timedelta(days=1)
                        time.sleep(1)
                        continue

                    # Reset retry count on success
                    retry_count = 0

                    # Get candles from response
                    candles = response.get("candles", [])
                    if candles:
                        # Handle dynamic column count based on whether OI is enabled
                        if enable_oi and len(candles[0]) == 7:
                            # Derivatives with OI: [timestamp, open, high, low, close, volume, oi]
                            df = pd.DataFrame(
                                candles,
                                columns=[
                                    "timestamp",
                                    "open",
                                    "high",
                                    "low",
                                    "close",
                                    "volume",
                                    "oi",
                                ],
                            )
                        else:
                            # Equity without OI: [timestamp, open, high, low, close, volume]
                            df = pd.DataFrame(
                                candles,
                                columns=["timestamp", "open", "high", "low", "close", "volume"],
                            )
                            # Add zero OI column for consistency
                            df["oi"] = 0

                        dfs.append(df)
                        logger.debug(
                            f"Got {len(candles)} candles for period {chunk_start} to {chunk_end}"
                        )
                    else:
                        logger.debug(f"No data available for period {chunk_start} to {chunk_end}")

                    # Add a small delay between chunks to avoid rate limiting
                    time.sleep(0.5)

                    # Move to next chunk
                    current_start = current_end + pd.Timedelta(days=1)

                except Exception as e:
                    logger.error(f"Error fetching chunk {chunk_start} to {chunk_end}: {e}")
                    if retry_count < max_retries:
                        retry_count += 1
                        logger.debug(f"Retrying... Attempt {retry_count} of {max_retries}")
                        time.sleep(2 * retry_count)
                        continue

                    # If max retries reached, move to next chunk
                    retry_count = 0
                    current_start = current_end + pd.Timedelta(days=1)
                    time.sleep(1)
                    continue

            # If no data was found, return empty DataFrame
            if not dfs:
                logger.warning("No data was collected for the entire period")
                return pd.DataFrame(columns=["timestamp", "open", "high", "low", "close", "volume"])

            # Combine all chunks
            final_df = pd.concat(dfs, ignore_index=True)

            # Sort by timestamp and remove duplicates
            final_df = final_df.sort_values("timestamp").drop_duplicates(
                subset=["timestamp"], keep="first"
            )

            logger.info(f"Successfully collected data: {len(final_df)} total candles")
            return final_df

        except Exception as e:
            error_msg = f"Error fetching historical data for {exchange}:{symbol}"
            logger.exception(error_msg)
            raise Exception(f"{error_msg}: {e}")

    def get_depth(self, symbol: str, exchange: str) -> dict:
        """
        Get market depth for given symbol
        Args:
            symbol: Trading symbol
            exchange: Exchange (e.g., NSE, BSE)
        Returns:
            dict: Market depth data with OHLC, volume and open interest
        """
        try:
            br_symbol = get_br_symbol(symbol, exchange)
            encoded_symbol = urllib.parse.quote(br_symbol)

            response = get_api_response(
                f"/data/depth?symbol={encoded_symbol}&ohlcv_flag=1", self.auth_token
            )
            logger.debug(f"Fyers depth API FULL response: {json.dumps(response, indent=2)}")

            if response.get("s") != "ok":
                error_msg = f"Error from Fyers API: {response.get('message', 'Unknown error')}"
                logger.error(error_msg)
                raise Exception(error_msg)

            depth_data = response.get("d", {}).get(br_symbol)
            if not depth_data:
                logger.warning(f"No market depth data found for {br_symbol} in API response.")
                return {}

            bids = depth_data.get("bids", [])
            asks = depth_data.get("ask", [])  # Note: Fyers uses 'ask' (singular) not 'asks'

            # Debug: Log the raw bids and asks structure
            logger.debug(f"Raw bids data: {bids}")
            logger.debug(f"Raw asks data: {asks}")

            empty_entry = {"price": 0, "quantity": 0}
            # Handle potential missing 'volume' key by using .get() with default 0
            bids_formatted = [
                {"price": b.get("price", 0), "quantity": b.get("volume", 0)} for b in bids[:5]
            ]
            asks_formatted = [
                {"price": a.get("price", 0), "quantity": a.get("volume", 0)} for a in asks[:5]
            ]

            while len(bids_formatted) < 5:
                bids_formatted.append(empty_entry)
            while len(asks_formatted) < 5:
                asks_formatted.append(empty_entry)

            return {
                "bids": bids_formatted,
                "asks": asks_formatted,
                "totalbuyqty": depth_data.get("totalbuyqty", 0),
                "totalsellqty": depth_data.get("totalsellqty", 0),
                "high": depth_data.get("h", 0),
                "low": depth_data.get("l", 0),
                "ltp": depth_data.get("ltp", 0),
                "ltq": depth_data.get("ltq", 0),
                "open": depth_data.get("o", 0),
                "prev_close": depth_data.get("c", 0),
                "volume": depth_data.get("v", 0),
                "oi": int(depth_data.get("oi", 0)),
            }

        except Exception as e:
            logger.exception(f"Error fetching market depth for {exchange}:{symbol}")
            raise Exception(f"Error fetching market depth: {e}")
