"""IIFL Capital database modules."""
