"""
delta_websocket.py
Low-level WebSocket client for Delta Exchange real-time feed.

Endpoint : wss://socket.india.delta.exchange
Protocol : JSON over secure WebSocket
Auth msg : { "type": "auth", "payload": { "api-key": "...", "signature": "...", "timestamp": "..." } }
Signature: HMAC-SHA256(api_secret, "GET" + timestamp + "/live")

Public channels  (no auth needed):
  subscribe:  { "type": "subscribe", "payload": { "channels": [{ "name": "v2/ticker", "symbols": ["BTCUSD"] }] } }
  unsubscribe: { "type": "unsubscribe", ... }

Channel names:
  v2/ticker          -> ticker updates (mark_price, open, high, low, volume, oi, best_bid, best_ask)
  l2_orderbook       -> level-2 order book (buy/sell lists with price+size)
  orders             -> order updates (requires auth)
  positions          -> position updates (requires auth)

Incoming message examples:
  Ticker:  { "type": "v2/ticker", "symbol": "BTCUSD",
             "mark_price": "67000", "open": 66000, "high": 68000,
             "low": 65000, "close": 66500, "volume": 1234,
             "oi": "5000", "quotes": { "best_bid": "66990", "best_ask": "67010" } }

  L2 book: { "type": "l2_orderbook", "symbol": "BTCUSD",
             "buy":  [{"price": "66990", "size": 1000, "depth": 1}, ...],
             "sell": [{"price": "67010", "size":  800, "depth": 1}, ...] }

References: https://docs.delta.exchange/#websocket-channels
"""

import hashlib
import hmac
import json
import logging
import os
import ssl
import threading
import time

import websocket

logger = logging.getLogger("delta_websocket")


class DeltaWebSocket:
    """
    Thin WebSocket client for the Delta Exchange streaming API.

    Usage
    -----
    ws = DeltaWebSocket(api_key="...", api_secret="...", on_message=cb)
    ws.connect()
    ws.subscribe_ticker(["BTCUSD", "ETHUSD"])
    ws.subscribe_l2_orderbook(["BTCUSD"])
    ...
    ws.close()
    """

    # ── constants ─────────────────────────────────────────────────────────────
    WS_URL            = "wss://socket.india.delta.exchange"
    HEARTBEAT_INTERVAL = 30      # seconds between pings
    MSG_TYPE_AUTH      = "key-auth"
    MSG_TYPE_SUB       = "subscribe"
    MSG_TYPE_UNSUB     = "unsubscribe"
    CHANNEL_TICKER     = "v2/ticker"
    CHANNEL_L2_BOOK    = "l2_orderbook"
    # Private authenticated channels (require auth message to be sent first)
    CHANNEL_ORDERS    = "orders"      # real-time order fill / cancel / modify events
    CHANNEL_POSITIONS = "positions"   # real-time position updates
    CHANNEL_MARGINS   = "margins"     # real-time margin / wallet changes

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        on_message=None,
        on_error=None,
        on_open=None,
        on_close=None,
        max_retry_attempt: int = 5,
        retry_delay: int = 5,
        retry_multiplier: int = 2,
    ):
        self.api_key    = api_key
        self.api_secret = api_secret

        # User-supplied callbacks
        self.on_message = on_message  or (lambda ws, msg: None)
        self.on_error   = on_error    or (lambda ws, err: None)
        self.on_open    = on_open     or (lambda ws: None)
        self.on_close   = on_close    or (lambda ws: None)

        self.max_retry_attempt = max_retry_attempt
        self.retry_delay       = retry_delay
        self.retry_multiplier  = retry_multiplier

        self.wsapp:  websocket.WebSocketApp | None = None
        self._lock   = threading.Lock()
        self._connected = False
        self._stop_flag = False
        # Persistent subscription registry: deterministic_key → raw JSON message.
        # Serves two purposes:
        #   1. Pre-connect buffer: messages accumulate here and are sent in
        #      _ws_on_open when the socket first connects.
        #   2. Reconnect replay: the dict is NEVER cleared, so every reconnect
        #      (after a disconnect) re-sends all active subscriptions, restoring
        #      all streams automatically without the caller needing to re-subscribe.
        # Unsubscribe removes the entry so the channel is not replayed.
        self._active_sub_msgs: dict[str, str] = {}

    # ── auth helper ───────────────────────────────────────────────────────────

    def _build_auth_msg(self) -> str:
        """Build HMAC-SHA256 authenticated auth message."""
        timestamp = str(int(time.time()))
        message   = f"GET{timestamp}/live"
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            message.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        payload = {
            "type": self.MSG_TYPE_AUTH,
            "payload": {
                "api-key":   self.api_key,
                "signature": signature,
                "timestamp": timestamp,
            },
        }
        return json.dumps(payload)

    # ── subscribe / unsubscribe helpers ──────────────────────────────────────

    def _build_sub_msg(self, channel: str, symbols: list[str], unsub=False) -> str:
        msg = {
            "type": self.MSG_TYPE_UNSUB if unsub else self.MSG_TYPE_SUB,
            "payload": {
                "channels": [{"name": channel, "symbols": symbols}]
            },
        }
        return json.dumps(msg)

    def _send(self, text: str) -> None:
        if self.wsapp and self._connected:
            try:
                self.wsapp.send(text)
            except Exception as exc:
                logger.error("DeltaWS _send error: %s", exc)

    def _queue_or_send(self, key: str, msg: str) -> None:
        """
        Register and immediately send (or buffer) a subscription message.

        The key is a deterministic string identifying the subscription
        (e.g. "ticker:BTCUSD,ETHUSD") so duplicates overwrite rather than
        stack, and unsubscribes can remove the exact entry.

        Why the lock spans both the registry write AND the send:
          Holding the lock across the send prevents the TOCTOU race where
          _ws_on_close flips _connected=False between our check and the send,
          causing the message to be dropped from both the wire and the registry.

        On reconnect, _ws_on_open replays the entire _active_sub_msgs dict,
        so no explicit re-subscribe call from the caller is ever needed.
        """
        with self._lock:
            self._active_sub_msgs[key] = msg   # persist for reconnect replay
            if self._connected:
                try:
                    if self.wsapp:
                        self.wsapp.send(msg)
                except Exception as exc:
                    logger.error("DeltaWS _send error: %s", exc)
                    # Send failed mid-flight; message already stored in
                    # _active_sub_msgs and will be replayed on reconnect.
            else:
                logger.debug("DeltaWS buffered subscription (not connected): %s", key)

    # ── public API ────────────────────────────────────────────────────────────

    @staticmethod
    def _sub_key(channel: str, symbols: list[str]) -> str:
        """Deterministic registry key for a public channel subscription."""
        return f"{channel}:{','.join(sorted(symbols))}"

    def subscribe_ticker(self, symbols: list[str]) -> None:
        """Subscribe to v2/ticker channel for the given symbols."""
        self._queue_or_send(
            self._sub_key(self.CHANNEL_TICKER, symbols),
            self._build_sub_msg(self.CHANNEL_TICKER, symbols),
        )

    def subscribe_l2_orderbook(self, symbols: list[str]) -> None:
        """Subscribe to l2_orderbook channel for the given symbols."""
        self._queue_or_send(
            self._sub_key(self.CHANNEL_L2_BOOK, symbols),
            self._build_sub_msg(self.CHANNEL_L2_BOOK, symbols),
        )

    def unsubscribe_ticker(self, symbols: list[str]) -> None:
        key = self._sub_key(self.CHANNEL_TICKER, symbols)
        with self._lock:
            self._active_sub_msgs.pop(key, None)
        self._send(self._build_sub_msg(self.CHANNEL_TICKER, symbols, unsub=True))

    def unsubscribe_l2_orderbook(self, symbols: list[str]) -> None:
        key = self._sub_key(self.CHANNEL_L2_BOOK, symbols)
        with self._lock:
            self._active_sub_msgs.pop(key, None)
        self._send(self._build_sub_msg(self.CHANNEL_L2_BOOK, symbols, unsub=True))

    # ── private (authenticated) channel subscriptions ─────────────────────────

    def _build_private_sub_msg(self, channel: str, unsub: bool = False) -> str:
        """Build a subscribe/unsubscribe message for account-level channels.

        'orders' and 'positions' require "symbols": ["all"] or Delta Exchange
        sends no data (per API docs).  'margins' works without a symbols list.
        """
        channel_entry: dict = {"name": channel}
        if channel in (self.CHANNEL_ORDERS, self.CHANNEL_POSITIONS):
            channel_entry["symbols"] = ["all"]
        return json.dumps({
            "type": self.MSG_TYPE_UNSUB if unsub else self.MSG_TYPE_SUB,
            "payload": {"channels": [channel_entry]},
        })

    def subscribe_orders_channel(self) -> None:
        """Subscribe to the authenticated 'orders' channel.

        Delivers real-time order fill, cancel, and modify events for the
        authenticated user.  The WebSocket session must be authenticated first
        (the auth message is sent automatically in _ws_on_open).
        """
        self._queue_or_send(self.CHANNEL_ORDERS, self._build_private_sub_msg(self.CHANNEL_ORDERS))

    def subscribe_positions_channel(self) -> None:
        """Subscribe to the authenticated 'positions' channel.

        Delivers real-time position updates (size, entry price, PnL) whenever
        a position changes for the authenticated user.
        """
        self._queue_or_send(self.CHANNEL_POSITIONS, self._build_private_sub_msg(self.CHANNEL_POSITIONS))

    def subscribe_margins_channel(self) -> None:
        """Subscribe to the authenticated 'margins' channel.

        Delivers real-time wallet and margin balance updates whenever a fill,
        funding payment, or realised-PnL event changes the account balance.
        """
        self._queue_or_send(self.CHANNEL_MARGINS, self._build_private_sub_msg(self.CHANNEL_MARGINS))

    def connect(self) -> None:
        """Start the WebSocket connection (blocking — run in a thread)."""
        self._stop_flag = False
        retry_attempts = 0
        delay = self.retry_delay

        while not self._stop_flag and retry_attempts <= self.max_retry_attempt:
            try:
                logger.info("DeltaWS connecting to %s (attempt %s)", self.WS_URL, retry_attempts + 1)
                self.wsapp = websocket.WebSocketApp(
                    self.WS_URL,
                    on_open    = self._ws_on_open,
                    on_message = self._ws_on_message,
                    on_error   = self._ws_on_error,
                    on_close   = self._ws_on_close,
                )
                self.wsapp.run_forever(
                    sslopt={"cert_reqs": ssl.CERT_REQUIRED},
                    ping_interval=self.HEARTBEAT_INTERVAL,
                    ping_timeout=10,
                )
                # run_forever returns when connection closes
                if self._stop_flag:
                    break
                retry_attempts += 1
                logger.warning("DeltaWS disconnected; retry in %ss", delay)
                time.sleep(delay)
                delay = min(delay * self.retry_multiplier, 60)

            except Exception as exc:
                logger.error("DeltaWS connect error: %s", exc)
                retry_attempts += 1
                time.sleep(delay)
                delay = min(delay * self.retry_multiplier, 60)

        if retry_attempts > self.max_retry_attempt:
            logger.error("DeltaWS max reconnect attempts reached; giving up")

    def close_connection(self) -> None:
        """Cleanly stop the WebSocket."""
        self._stop_flag = True
        if self.wsapp:
            try:
                self.wsapp.close()
            except Exception:
                pass

    # ── internal WS callbacks ─────────────────────────────────────────────────

    def _ws_on_open(self, wsapp) -> None:
        logger.info("DeltaWS connected")

        # Authenticate (required for order/position channels)
        try:
            wsapp.send(self._build_auth_msg())
        except Exception as exc:
            logger.error("DeltaWS auth send error: %s", exc)

        # Set _connected and replay all active subscriptions atomically.
        # _active_sub_msgs serves as both the pre-connect buffer (messages
        # registered before the socket was up) AND the reconnect replay list
        # (messages registered during a previous session that must be
        # resubscribed after a disconnect/reconnect).  The dict is never
        # cleared, so every reconnect restores all streams automatically.
        with self._lock:
            self._connected = True
            to_replay = list(self._active_sub_msgs.values())

        for msg in to_replay:
            try:
                wsapp.send(msg)
            except Exception as exc:
                logger.error("DeltaWS subscription replay send error: %s", exc)

        self.on_open(wsapp)

    def _ws_on_message(self, wsapp, raw) -> None:
        try:
            msg = json.loads(raw)
        except Exception:
            logger.debug("DeltaWS non-JSON message: %s", raw[:120])
            return

        msg_type = msg.get("type", "")

        if msg_type in ("key-auth", "subscriptions"):
            logger.info("DeltaWS ack: %s", msg_type)
            return

        if msg_type in ("error",):
            logger.error("DeltaWS server error: %s", msg)
            return

        logger.debug("DeltaWS dispatching: type=%s symbol=%s", msg_type, msg.get("symbol", ""))
        self.on_message(wsapp, msg)

    def _ws_on_error(self, wsapp, error) -> None:
        logger.error("DeltaWS error: %s", error)
        self.on_error(wsapp, error)

    def _ws_on_close(self, wsapp, *args) -> None:
        logger.info("DeltaWS closed")
        # Acquire the lock before clearing _connected so that any subscribe
        # call currently deciding whether to send vs. queue (also under the
        # same lock via _queue_or_send) completes atomically before we flip
        # the flag.  Without this, _ws_on_close could clear _connected between
        # the lock release in the old send_now pattern and the actual send,
        # silently dropping the message from both the wire and the queue.
        with self._lock:
            self._connected = False
        self.on_close(wsapp)
