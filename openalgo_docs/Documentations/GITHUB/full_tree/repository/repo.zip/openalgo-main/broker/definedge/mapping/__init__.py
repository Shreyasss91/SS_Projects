# DefinedGe Securities mapping modules
